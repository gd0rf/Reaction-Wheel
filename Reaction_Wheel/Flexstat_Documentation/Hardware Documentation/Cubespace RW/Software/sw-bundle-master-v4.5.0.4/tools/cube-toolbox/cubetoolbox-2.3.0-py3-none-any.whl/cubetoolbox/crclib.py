"""CRC module."""
import numpy as np


class CRC32(object):
    """CRC32 calculator."""

    def __init__(self, poly=0xEDB88320, init=0xFFFFFFFF, crc_exclude=None):
        """Initialize class."""
        self.poly = np.uint32(poly)
        self.init = np.uint64(init)
        self.crc_exclude = crc_exclude
        self.crc_table = None
        self._init_crc_table()

    def _init_crc_table(self):
        """Initialize crc table."""
        self.crc_table = np.array(np.zeros(256), dtype=np.uint32)
        for i in range(0, 256):
            crc = np.uint32(i)
            for j in range(0, 8):
                temp = crc & np.uint32(0x00000001)
                if temp == np.uint32(0x00000001):
                    crc = (crc >> 1) ^ self.poly
                else:
                    crc = crc >> 1
            self.crc_table[i] = crc

    def calculate_crc(self, data):
        """Calculate CRC."""
        crc_size = len(data)
        if self.crc_exclude is not None and self.crc_exclude is True:
            crc_size -= 4  # Do not crc over the last 4-byte, assumed to be the crc region itself
        crc = self.init
        for i in range(0, crc_size):
            long_c = np.uint64(0x000000FF) & np.uint8(data[i])
            temp = crc ^ long_c
            crc = (crc >> np.uint64(8)) ^ self.crc_table[temp & np.uint8(0xff)]
        crc ^= np.uint64(0xFFFFFFFF)
        return np.uint32(crc & np.uint64(0xFFFFFFFF))
