"""nodedefs."""
import os
import pathlib
import re

# Globals

gpath = None


# Set the nodedefs location

def location(path):
    """location."""
    global gpath

    gpath = path


# Load the nodedefs nodes

def nodes():
    """nodes."""
    global gpath

    nlist = []

    if gpath is None:
        print('Error: Path not set')
        return nlist

    for f in pathlib.Path(gpath).glob('*/*.xml'):
        node = os.path.basename(os.path.dirname(f))
        if node not in nlist:
            nlist.append(node)

    if not nlist:
        print('Error: Path contains no nodedefs for nodes')

    return nlist


# Load the nodedefs apps

def apps(node):
    """apps."""
    global gpath

    alist = []

    if gpath is None:
        print('Error: Path not set')
        return alist

    for f in pathlib.Path(gpath).glob('*/*.xml'):
        if re.search('.*' + node + '.*', str(f)) is not None:
            app = os.path.basename(f)
            # Not common xml files
            if re.search('.*common.*', app) is None:

                robj = re.search('(.*).xml', app)
                if robj is not None:
                    a = robj.groups()[0]

                    if a not in alist:
                        alist.append(a)

    if not alist:
        print('Error: Path contains no nodedefs for apps')

    return alist
