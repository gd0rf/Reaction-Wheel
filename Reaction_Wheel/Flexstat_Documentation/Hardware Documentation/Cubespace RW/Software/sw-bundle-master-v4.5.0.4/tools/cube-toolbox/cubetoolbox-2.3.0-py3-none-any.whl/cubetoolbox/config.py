"""Convert a config CFG to binary (.BIN) ready for flashing."""

import os
import json
import numpy as np
import cubetoolbox.crclib as crclib
import cubetoolbox.constants as constants

# Mapping between type name and data representation
_BASE_MAP = {
    'Boolean': np.uint32,
    'U8': np.uint8,
    'S8': np.int8,
    'U16': np.uint16,
    'S16': np.int16,
    'U32': np.uint32,
    'S32': np.int32,
    'U64': np.uint64,
    'S64': np.int64,
    'F32': np.float32,
    'F64': np.float64,
    'Text': np.string_,
}


class ConfigError(Exception):
    """Config Formatting Exception."""

    pass


def debug_print(str):
    """Print out debug information if the global VERBOSE flag is set."""
    global VERBOSE

    if VERBOSE == 1:
        print(str)


def internal_base_type(typedesc):
    """
    Return true if the type is a base type, and not an Enum.

    Note that Text is not supported.

    Arguments:
        typedesc - String type description

    Returns:
        True if base type, False if Enum
    """
    basetypes = ['U8', 'S8', 'U16', 'S16', 'U32', 'S32', 'U64', 'S64', 'F32', 'F64', 'Boolean', 'Text']
    if typedesc in basetypes:
        return True
    else:
        return False


def internal_other_bases_type(typedesc):
    """
    Return true if the type is a base type, which may be specified in hex, octal or binary.

    Note that Text is not supported.

    Arguments:
        typedesc - String type description

    Returns:
        True if base type, False if Enum
    """
    basetypes = ['U8', 'U16', 'U32', 'U64']
    if typedesc in basetypes:
        return True
    else:
        return False


def internal_string_bases_type(typedesc):
    """
    Return true if the type is a stringbase type.

    Arguments:
        typedesc - String type description

    Returns:
        True if Text base type, False if Enum
    """
    if typedesc == 'Text':
        return True
    else:
        return False


def config_field_value_valid(value, ctype):
    """
    Make sure the literal is valid (has not c style suffixes).

    Arguments:
        value - String representation of value

    Returns:
        True if compatible, False is not
    """
    # Make sure no suffix
    float_list = ['F32', 'F64']
    int_list = ['U8', 'S8', 'U16', 'S16', 'U32', 'S32', 'U64', 'S64', 'Boolean']
    if ctype in int_list:
        try:
            int(value, 0)
            return True
        except ValueError:
            return False
    elif ctype in float_list:
        try:
            float(value)
            return True
        except ValueError:
            return False
    elif ctype == 'Text':
        try:
            str(value)
            return True
        except ValueError:
            return False
    else:
        return False


def config_field_value_range(value, ctype):
    """
    Make sure the literal is valid (has not c style suffixes).

    Arguments:
        value - String representation of value

    Returns:
        True if compatible, False is not
    """
    # Make sure no suffix
    float_list = ['F32', 'F64']
    int_list = ['U8', 'S8', 'U16', 'S16', 'U32', 'S32', 'U64', 'S64', 'Boolean']

    def is_u8(n):
        return n >= 0 and n < 256

    def is_s8(n):
        return n >= -128 and n < 128

    def is_u16(n):
        return n >= 0 and n < 65536

    def is_s16(n):
        return n >= -32768 and n < 32768

    def is_u32(n):
        return n >= 0 and n < 4294967296

    def is_s32(n):
        return n >= -2147483648 and n < 2147483648

    def is_u64(n):
        return n >= 0 and n < 18446744073709551616

    def is_s64(n):
        return n >= -9223372036854775808 and n < 9223372036854775808

    def is_bool(n):
        return n >= 0 and n < 2

    if ctype in int_list:
        number = int(value, 0)
        if ctype == 'U8':
            return is_u8(number)
        elif ctype == 'S8':
            return is_s8(number)
        elif ctype == 'U16':
            return is_u16(number)
        elif ctype == 'S16':
            return is_s16(number)
        elif ctype == 'U32':
            return is_u32(number)
        elif ctype == 'S32':
            return is_s32(number)
        elif ctype == 'U64':
            return is_u64(number)
        elif ctype == 'S64':
            return is_s64(number)
        elif ctype == 'Boolean':
            return is_bool(number)

    elif ctype in float_list:
        number = float(value)
        # No float checking
        return True
    elif ctype == 'Text':
        return True
    else:
        return False


def load_config(json_in):
    """
    Loads a configuration json from a file.

    Arguments:
        json_in - Load the JSON configuration file

    Returns:
        loaded_config - config read from file
    """
    loaded_config = None

    # Check if file exists
    if not os.path.exists(json_in):
        raise IOError("File '{}' does not exist".format(json_in))

    # Read file
    with open(json_in, 'r') as json_file:
        loaded_config = json.load(json_file)

    assert loaded_config is not None

    return loaded_config


def enumerate_config(config):
    """
    Replace enums with S32 and correct value.

    Arguments:
        config - Config file contents

    """
    # Load the config structures
    loaded_configs = config['configs']

    # Load the enum definitions
    loaded_types = config['types']

    # In order to convert the config to binary format, we need to
    # convert Enums to a numerical representation
    for config_key in loaded_configs.keys():

        # Each config structure has a number of fields
        for field_key in loaded_configs[config_key]['contents'].keys():

            field_type = loaded_configs[config_key]['contents'][field_key]['type']

            # Check if the type is a base type, or an Enum that needs conversion to a number
            if internal_base_type(field_type) is False:

                # The type is not a base type. Is this type included in the config file?
                type_info = loaded_types.get(field_type)

                # Detect a broken/legacy config file
                if type_info is None:
                    raise ConfigError(
                        'Config file config ({}) references a type ({}) not included in the file'.format(
                            loaded_configs[config_key]['type'], field_type))

                # find the Enum field in the Enum definition
                if loaded_configs[config_key]['contents'][field_key]['value'] in type_info['fields'].keys():

                    # Here we replace the Enum field with a numerical representation
                    # by looking up the value in the config file enum list
                    loaded_configs[config_key]['contents'][field_key]['value'] = (
                        type_info['fields'][loaded_configs[config_key]['contents'][field_key]['value']]['value']
                    )

                    # We convert Enums to S32
                    loaded_configs[config_key]['contents'][field_key]['type'] = 'S32'

                # There might be an integer value, cast as an enum - let's check
                elif f'({field_type})' in loaded_configs[config_key]['contents'][field_key]['value']:
                    try:
                        # Remove the casting from the value
                        val = loaded_configs[config_key]['contents'][field_key]['value'].replace(f'({field_type})', '')
                        loaded_configs[config_key]['contents'][field_key]['value'] = val

                        # We convert Enums to S32
                        loaded_configs[config_key]['contents'][field_key]['type'] = 'S32'

                    except Exception:
                        raise ConfigError('Config file config ({}) is incorrectly casting to type ({})'.format(
                            loaded_configs[config_key]['type'], field_type))
                else:
                    raise ConfigError(
                        'Config config ({}) references a type ({}) member ({}) that does not exist'.format(
                            loaded_configs[config_key]['type'], field_type, loaded_configs[config_key]['contents'][field_key]['value']))

    # At this point all types and value are based on base types.
    # We need to check all the values are within the exected ranges.
    for config_key in loaded_configs.keys():

        # Each config structure has a number of fields
        for field_key in loaded_configs[config_key]['contents'].keys():

            field_type = loaded_configs[config_key]['contents'][field_key]['type']
            field_value = loaded_configs[config_key]['contents'][field_key]['value']

            # Can we convert it?
            if config_field_value_valid(field_value, field_type) is False:
                raise ConfigError('Cannot convert config ({}) element ({}) value. See value ({})'.format(
                    loaded_configs[config_key]['type'], field_key, field_value))

            # Is the range valid for the specific precision
            if config_field_value_range(field_value, field_type) is False:
                raise ConfigError('Value range issue for config ({}) element ({}). See value ({})'.format(
                    loaded_configs[config_key]['type'], field_key, field_value))


def compile(json_in, output, default_raw=False):
    """
    Compile the jason to binary format.

    Arguments:
        json_in - JSON content
        output - Binary
    """
    # Load the config from JSON
    config = load_config(json_in)

    # Replace all the Enum fields with their respective number representations
    enumerate_config(config)

    # The descriptors must go first, in classId order
    class_descriptors = config['classes']

    # This is the binary config
    compiled_config = b''

    # Process in classId order, and serialize
    for _, value in sorted(class_descriptors.items(), key=lambda item: int(item[1]['classId']['value'])):
        class_type = value['classId']['type']
        class_value = value['classId']['value']
        compiled_config += _BASE_MAP[class_type](class_value).tobytes()
        class_type = value['classOffset']['type']
        class_value = value['classOffset']['value']
        compiled_config += _BASE_MAP[class_type](class_value).tobytes()
        class_type = value['classSize']['type']
        class_value = value['classSize']['value']
        compiled_config += _BASE_MAP[class_type](class_value).tobytes()
        class_type = value['classInstances']['type']
        class_value = value['classInstances']['value']
        compiled_config += _BASE_MAP[class_type](class_value).tobytes()

    # Configs from the JSON file
    config_descriptors = config['configs']

    # Process in classId order and serialize the configs
    for key, _ in sorted(class_descriptors.items(), key=lambda item: int(item[1]['classId']['value'])):

        # Get all the matching class configs (instances of the same class)
        class_configs = {k: v for k, v in config_descriptors.items() if v['class'] == key}

        # Process them in instance order
        for _, config in sorted(class_configs.items(), key=lambda item: int(item[1]['instance_number'])):
            # Note we must serialize in the exact order the struct was written in
            for field_key, _ in sorted(config['contents'].items(), key=lambda item: int(item[1]['order'])):
                field_type = config['contents'][field_key]['type']
                field_value = config['contents'][field_key]['value']

                try:
                    field_type_array = config['contents'][field_key]['array']
                except KeyError:
                    # This try-except statement is placed here to allow for old config files
                    # That don't contain an 'array' field (i.e. do not yet support Text in configs)
                    # to be compiled to a binary blob.
                    # The array field would effectively be 0 for all items in an old config file.
                    if internal_string_bases_type(field_type):
                        raise ConfigError(f'Type {field_type} is should be an array!')

                # If the type is unsigned, it may be specified as another base (hex, octal, binary)
                if internal_other_bases_type(field_type):
                    value_convert = int(field_value, 0)
                elif internal_string_bases_type(field_type):
                    value_convert = np.chararray((1, 1), field_type_array)  # Add padding to the end
                    value_convert[:] = field_value
                else:
                    value_convert = field_value

                # Write the value to a serialized byte array
                compiled_config += _BASE_MAP[field_type](value_convert).tobytes()

    # The CRC U32 is last. Lets remove it so we can override it.
    compiled_config = compiled_config[:-4]

    # Do not include crc for raw defult to be embedded in to app image
    if default_raw is not True:
        # Compute and populate the new CRC
        crc32 = crclib.CRC32(poly=constants.CRC_POLY_EMBEDDED)
        crc = crc32.calculate_crc(compiled_config)
        compiled_config += _BASE_MAP['U32'](crc).tobytes()

    with open(output, 'wb') as binary_file:
        binary_file.write(compiled_config)


def main():
    """Main function."""
    return True
