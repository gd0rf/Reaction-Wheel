import enum
import numpy as np

class Boolean(object):
    def __init__(self, value, array=1):
        self.np_value = np.uint32(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.uint32

    def tsize():
        return np.uint32().itemsize

    def size(self):
        return self.np_value.itemsize

class U8(object):
    def __init__(self, value, array=1):
        self.np_value = np.uint8(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.uint8

    def tsize():
        return np.uint8().itemsize

    def size(self):
        return self.np_value.itemsize

class S8(object):
    def __init__(self, value, array=1):
        self.np_value = np.int8(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.int8

    def tsize():
        return np.int8().itemsize

    def size(self):
        return self.np_value.itemsize

class U16(object):
    def __init__(self, value, array=1):
        self.np_value = np.uint16(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.uint16

    def tsize():
        return np.uint16().itemsize

    def size(self):
        return self.np_value.itemsize

class S16(object):
    def __init__(self, value, array=1):
        self.np_value = np.int16(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.int16

    def tsize():
        return np.int16().itemsize

    def size(self):
        return self.np_value.itemsize

class U32(object):
    def __init__(self, value, array=1):
        self.np_value = np.uint32(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.uint32

    def tsize():
        return np.uint32().itemsize

    def size(self):
        return self.np_value.itemsize

class S32(object):
    def __init__(self, value, array=1):
        self.np_value = np.int32(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

    def size(self):
        return self.np_value.itemsize

class U64(object):
    def __init__(self, value, array=1):
        self.np_value = np.uint64(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.uint64

    def tsize():
        return np.uint64().itemsize

    def size(self):
        return self.np_value.itemsize

class S64(object):
    def __init__(self, value, array=1):
        self.np_value = np.int64(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.int64

    def tsize():
        return np.int64().itemsize

    def size(self):
        return self.np_value.itemsize

class F32(object):
    def __init__(self, value, array=1):
        self.np_value = np.float32(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.float32

    def tsize():
        return np.float32().itemsize

    def size(self):
        return self.np_value.itemsize

class F64(object):
    def __init__(self, value, array=1):
        self.np_value = np.float64(value)

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.float64

    def tsize():
        return np.float64().itemsize

    def size(self):
        return self.np_value.itemsize

class Text(object):
    def __init__(self, value, array=1):
        self.np_value = np.chararray((1,1), array)
        self.np_value[:] = value

    def tobytes(self):
        return self.np_value.tobytes()

    def dtype():
        return np.chararray

    def tsize():
        return 1

    def size(self):
        return self.np_value.itemsize


class ConfigDef_Access(object):
    class ThisEnum(enum.Enum):
        NONE = None
        CONFIG_DEF__ACCESS_RW_USR = 0
        CONFIG_DEF__ACCESS_RO_USR = 1

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class ConfigDef_TctlmV1CanAddresses(object):
    class ThisEnum(enum.Enum):
        NONE = None
        CONFIG_DEF__TCTLMV1_CAN_ADDR_BROADCAST = 0
        CONFIG_DEF__TCTLMV1_CAN_ADDR_UNASSIGNED = 1
        CONFIG_DEF__TCTLMV1_CAN_ADDR_COMPUTER0 = 2
        CONFIG_DEF__TCTLMV1_CAN_ADDR_COMPUTER1 = 3
        CONFIG_DEF__TCTLMV1_CAN_ADDR_WHEEL0 = 4
        CONFIG_DEF__TCTLMV1_CAN_ADDR_WHEEL1 = 5
        CONFIG_DEF__TCTLMV1_CAN_ADDR_WHEEL2 = 6
        CONFIG_DEF__TCTLMV1_CAN_ADDR_WHEEL3 = 7
        CONFIG_DEF__TCTLMV1_CAN_ADDR_WHEEL4 = 8
        CONFIG_DEF__TCTLMV1_CAN_ADDR_STAR0 = 9
        CONFIG_DEF__TCTLMV1_CAN_ADDR_STAR1 = 10
        CONFIG_DEF__TCTLMV1_CAN_ADDR_STAR2 = 11
        CONFIG_DEF__TCTLMV1_CAN_ADDR_STAR3 = 12
        CONFIG_DEF__TCTLMV1_CAN_ADDR_SENSE0 = 13
        CONFIG_DEF__TCTLMV1_CAN_ADDR_SENSE1 = 14
        CONFIG_DEF__TCTLMV1_CAN_ADDR_SENSE2 = 15
        CONFIG_DEF__TCTLMV1_CAN_ADDR_SENSE3 = 16
        CONFIG_DEF__TCTLMV1_CAN_ADDR_MAG0 = 17
        CONFIG_DEF__TCTLMV1_CAN_ADDR_MAG1 = 18
        CONFIG_DEF__TCTLMV1_CAN_ADDR_AURIGA0 = 19
        CONFIG_DEF__TCTLMV1_CAN_ADDR_AURIGA1 = 20
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE0 = 21
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_SLT0 = 22
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_PST3S0 = 23
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_PST3S1 = 24
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_NSSRWL0 = 25
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_NSSRWL1 = 26
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_NSSRWL2 = 27
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_NSSRWL3 = 28
        CONFIG_DEF__TCTLMV1_CAN_ADDR_IR0 = 29
        CONFIG_DEF__TCTLMV1_CAN_ADDR_IR1 = 30
        CONFIG_DEF__TCTLMV1_CAN_ADDR_NODE_BOOTLOADER = 31
        CONFIG_DEF__TCTLMV1_CAN_ADDR_INTERNAL_MAX = 32
        CONFIG_DEF__TCTLMV1_CAN_ADDR_PASSTHROUGH = 235
        CONFIG_DEF__TCTLMV1_CAN_ADDR_OBC = 240

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class ConfigDef_TctlmV1Rs485Addresses(object):
    class ThisEnum(enum.Enum):
        NONE = None
        CONFIG_DEF__TCTLMV1_RS485_ADDR_BROADCAST = 0
        CONFIG_DEF__TCTLMV1_RS485_ADDR_COMPUTER0 = 1
        CONFIG_DEF__TCTLMV1_RS485_ADDR_COMPUTER1 = 2
        CONFIG_DEF__TCTLMV1_RS485_ADDR_WHEEL0 = 3
        CONFIG_DEF__TCTLMV1_RS485_ADDR_WHEEL1 = 4
        CONFIG_DEF__TCTLMV1_RS485_ADDR_WHEEL2 = 5
        CONFIG_DEF__TCTLMV1_RS485_ADDR_WHEEL3 = 6
        CONFIG_DEF__TCTLMV1_RS485_ADDR_WHEEL4 = 7
        CONFIG_DEF__TCTLMV1_RS485_ADDR_STAR0 = 8
        CONFIG_DEF__TCTLMV1_RS485_ADDR_STAR1 = 9
        CONFIG_DEF__TCTLMV1_RS485_ADDR_STAR2 = 10
        CONFIG_DEF__TCTLMV1_RS485_ADDR_STAR3 = 11
        CONFIG_DEF__TCTLMV1_RS485_ADDR_SENSE0 = 12
        CONFIG_DEF__TCTLMV1_RS485_ADDR_SENSE1 = 13
        CONFIG_DEF__TCTLMV1_RS485_ADDR_SENSE2 = 14
        CONFIG_DEF__TCTLMV1_RS485_ADDR_SENSE3 = 15
        CONFIG_DEF__TCTLMV1_RS485_ADDR_MAG0 = 16
        CONFIG_DEF__TCTLMV1_RS485_ADDR_MAG1 = 17
        CONFIG_DEF__TCTLMV1_RS485_ADDR_AURIGA0 = 18
        CONFIG_DEF__TCTLMV1_RS485_ADDR_AURIGA1 = 19
        CONFIG_DEF__TCTLMV1_RS485_ADDR_NODE0 = 20
        CONFIG_DEF__TCTLMV1_RS485_ADDR_NODE1 = 21
        CONFIG_DEF__TCTLMV1_RS485_ADDR_NODE2 = 22
        CONFIG_DEF__TCTLMV1_RS485_ADDR_IR0 = 23
        CONFIG_DEF__TCTLMV1_RS485_ADDR_IR1 = 24
        CONFIG_DEF__TCTLMV1_RS485_ADDR_IR2 = 25
        CONFIG_DEF__TCTLMV1_RS485_ADDR_FUTURE0 = 26
        CONFIG_DEF__TCTLMV1_RS485_ADDR_FUTURE1 = 27
        CONFIG_DEF__TCTLMV1_RS485_ADDR_FUTURE2 = 28
        CONFIG_DEF__TCTLMV1_RS485_ADDR_FUTURE3 = 29
        CONFIG_DEF__TCTLMV1_RS485_ADDR_FUTURE4 = 30
        CONFIG_DEF__TCTLMV1_RS485_ADDR_OBC = 240

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class ConfigDef_InterfacePort(object):
    class ThisEnum(enum.Enum):
        NONE = None
        CONFIG_DEF__PORT_IFC_PORT_INVALID = 0
        CONFIG_DEF__PORT_IFC_ACTUATOR1 = 1
        CONFIG_DEF__PORT_IFC_ACTUATOR2 = 2
        CONFIG_DEF__PORT_IFC_ACTUATOR3 = 3
        CONFIG_DEF__PORT_IFC_ACTUATOR4 = 4
        CONFIG_DEF__PORT_IFC_SENSOR1 = 5
        CONFIG_DEF__PORT_IFC_SENSOR2 = 6
        CONFIG_DEF__PORT_IFC_SENSOR3 = 7
        CONFIG_DEF__PORT_IFC_SENSOR4 = 8
        CONFIG_DEF__PORT_IFC_SENSOR5 = 11
        CONFIG_DEF__PORT_IFC_SENSOR6 = 12
        CONFIG_DEF__PORT_IFC_SENSOR7 = 13
        CONFIG_DEF__PORT_IFC_SENSOR8 = 14
        CONFIG_DEF__PORT_IFC_PORT_MAX = 15

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class NodeDef_AbstractNodes(object):
    class ThisEnum(enum.Enum):
        NONE = None
        NODE_DEF__ABSTRACT_NODES_INVALID = 0
        NODE_DEF__ABSTRACT_NODES_COMPUTER = 1
        NODE_DEF__ABSTRACT_NODES_STR0 = 2
        NODE_DEF__ABSTRACT_NODES_STR1 = 3
        NODE_DEF__ABSTRACT_NODES_FSS0 = 4
        NODE_DEF__ABSTRACT_NODES_FSS1 = 5
        NODE_DEF__ABSTRACT_NODES_FSS2 = 6
        NODE_DEF__ABSTRACT_NODES_FSS3 = 7
        NODE_DEF__ABSTRACT_NODES_HSS0 = 8
        NODE_DEF__ABSTRACT_NODES_HSS1 = 9
        NODE_DEF__ABSTRACT_NODES_MAG0 = 10
        NODE_DEF__ABSTRACT_NODES_MAG1 = 11
        NODE_DEF__ABSTRACT_NODES_EXT0 = 12
        NODE_DEF__ABSTRACT_NODES_EXT1 = 13
        NODE_DEF__ABSTRACT_NODES_RWL0 = 14
        NODE_DEF__ABSTRACT_NODES_RWL1 = 15
        NODE_DEF__ABSTRACT_NODES_RWL2 = 16
        NODE_DEF__ABSTRACT_NODES_RWL3 = 17
        NODE_DEF__ABSTRACT_NODES_RWL4 = 18
        NODE_DEF__ABSTRACT_NODES_EXTGYR0 = 19
        NODE_DEF__ABSTRACT_NODES_EXTGYR1 = 20
        NODE_DEF__ABSTRACT_NODES_CQ0 = 21
        NODE_DEF__ABSTRACT_NODES_CQ1 = 22
        NODE_DEF__ABSTRACT_NODES_CQ2 = 23
        NODE_DEF__ABSTRACT_NODES_CQ3 = 24
        NODE_DEF__ABSTRACT_NODES_MAX = 25

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class NodeDef_Nodes(object):
    class ThisEnum(enum.Enum):
        NONE = None
        NODE_DEF__NODES_INVALID = 0
        NODE_DEF__NODES_CUBE_COMPUTER = 1
        NODE_DEF__NODES_CUBE_SENSE = 2
        NODE_DEF__NODES_CUBE_WHEEL = 3
        NODE_DEF__NODES_CUBE_IR = 4
        NODE_DEF__NODES_CUBE_MAG_DEPLOY = 5
        NODE_DEF__NODES_CUBE_MAG_COMPACT = 6
        NODE_DEF__NODES_CUBE_STAR = 7
        NODE_DEF__NODES_CUBE_AURIGA = 8
        NODE_DEF__NODES_CUBE_NODE = 9
        NODE_DEF__NODES_CUBE_NODE_SLT = 10
        NODE_DEF__NODES_CUBE_NODE_PST3S = 11
        NODE_DEF__NODES_CUBE_NODE_NSSRWL = 12
        NODE_DEF__NODES_EXTENDED = 15
        NODE_DEF__NODES_CUBE_NODE_QUAD = 16
        NODE_DEF__NODES_CUBE_NODE_QUAD_PST3S = 17
        NODE_DEF__NODES_CUBE_NODE_QUAD_NSSRWL = 18
        NODE_DEF__NODES_CUBE_NODE_QUAD_LITEFUFORS = 19
        NODE_DEF__NODES_MAX = 20
        NODE_DEF__NODES_UNIT_TEST = 21

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class NodeDef_CubeNodeVariant(object):
    class ThisEnum(enum.Enum):
        NONE = None
        NODE_DEF__CUBE_NODE_VARIANT_UNO = 0
        NODE_DEF__CUBE_NODE_VARIANT_QUAD = 1
        NODE_DEF__CUBE_NODE_VARIANT_MAX = 2

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class NodeDef_Programs(object):
    class ThisEnum(enum.Enum):
        NONE = None
        NODE_DEF__PROGRAMS_INVALID = 0
        NODE_DEF__PROGRAMS_CONTROL = 1
        NODE_DEF__PROGRAMS_BOOTLOADER = 4
        NODE_DEF__PROGRAMS_BOOTLOADER_NODE_52 = 5
        NODE_DEF__PROGRAMS_BOOTLOADER_NODE_R5 = 6
        NODE_DEF__PROGRAMS_HEALTH_CHECK = 7
        NODE_DEF__PROGRAMS_BALLOON = 8
        NODE_DEF__PROGRAMS_EMULATOR = 9
        NODE_DEF__PROGRAMS_MAX = 10

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize

class FileMeta_CubeSpaceFileType(object):
    class ThisEnum(enum.Enum):
        NONE = None
        FILE_META__CUBESPACE_FILE_BIN = 0
        FILE_META__CUBESPACE_FILE_CFG_BIN = 1
        FILE_META__CUBESPACE_FILE_EVENT_LOG = 2
        FILE_META__CUBESPACE_FILE_ERROR_LOG = 3
        FILE_META__CUBESPACE_FILE_IMAGE_BMP = 4
        FILE_META__CUBESPACE_FILE_GENERAL = 5
        FILE_META__CUBESPACE_FILE_MAX = 6

    def __init__(self, value, array=1):
        self.enum = self.ThisEnum(value)

    def value(self):
        return self.enum.value

    def string(self):
        return self.enum.__str__()

    def tobytes(self):
        return np.int32(self.enum.value).tobytes()

    def dtype():
        return np.int32

    def tsize():
        return np.int32().itemsize


class TypeDef_CubeSpaceFileMeta(object):
    def __init__(self):
        self.struct_items = list()
        self.meta_bytes = bytearray()
        self.meta_dict = dict()
        self.struct_size = 0

        new_item = dict()
        new_item['name'] = 'metaSize'
        new_item['type'] = 'U16'
        new_item['nd_type'] = U16.dtype()
        new_item['size'] = 1
        self.struct_size += U16.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'fileType'
        new_item['type'] = 'FileMeta_CubeSpaceFileType'
        new_item['nd_type'] = FileMeta_CubeSpaceFileType.dtype()
        new_item['size'] = 1
        self.struct_size += FileMeta_CubeSpaceFileType.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'fileSize'
        new_item['type'] = 'U32'
        new_item['nd_type'] = U32.dtype()
        new_item['size'] = 1
        self.struct_size += U32.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'crc'
        new_item['type'] = 'U32'
        new_item['nd_type'] = U32.dtype()
        new_item['size'] = 1
        self.struct_size += U32.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'flashAddress'
        new_item['type'] = 'U32'
        new_item['nd_type'] = U32.dtype()
        new_item['size'] = 1
        self.struct_size += U32.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'nodeType'
        new_item['type'] = 'U32'
        new_item['nd_type'] = U32.dtype()
        new_item['size'] = 1
        self.struct_size += U32.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'nodeProgram'
        new_item['type'] = 'U16'
        new_item['nd_type'] = U16.dtype()
        new_item['size'] = 1
        self.struct_size += U16.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vCfg'
        new_item['type'] = 'U16'
        new_item['nd_type'] = U16.dtype()
        new_item['size'] = 1
        self.struct_size += U16.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'serialNumber'
        new_item['type'] = 'Text'
        new_item['nd_type'] = Text.dtype()
        new_item['size'] = 12
        self.struct_size += Text.tsize() * 12
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'component'
        new_item['type'] = 'Text'
        new_item['nd_type'] = Text.dtype()
        new_item['size'] = 32
        self.struct_size += Text.tsize() * 32
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'program'
        new_item['type'] = 'Text'
        new_item['nd_type'] = Text.dtype()
        new_item['size'] = 32
        self.struct_size += Text.tsize() * 32
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vMajorProg'
        new_item['type'] = 'U8'
        new_item['nd_type'] = U8.dtype()
        new_item['size'] = 1
        self.struct_size += U8.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vMinorProg'
        new_item['type'] = 'U8'
        new_item['nd_type'] = U8.dtype()
        new_item['size'] = 1
        self.struct_size += U8.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vPatchProg'
        new_item['type'] = 'U16'
        new_item['nd_type'] = U16.dtype()
        new_item['size'] = 1
        self.struct_size += U16.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vMajorSys'
        new_item['type'] = 'U8'
        new_item['nd_type'] = U8.dtype()
        new_item['size'] = 1
        self.struct_size += U8.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vMinorSys'
        new_item['type'] = 'U8'
        new_item['nd_type'] = U8.dtype()
        new_item['size'] = 1
        self.struct_size += U8.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'vPatchSys'
        new_item['type'] = 'U16'
        new_item['nd_type'] = U16.dtype()
        new_item['size'] = 1
        self.struct_size += U16.tsize() * 1
        self.struct_items.append(new_item)
        new_item = dict()
        new_item['name'] = 'unixTimeSeconds'
        new_item['type'] = 'U32'
        new_item['nd_type'] = U32.dtype()
        new_item['size'] = 1
        self.struct_size += U32.tsize() * 1
        self.struct_items.append(new_item)

    def to_bytes(self, _metaSize=None, _fileType=None, _fileSize=None, _crc=None, _flashAddress=None, _nodeType=None, _nodeProgram=None, _vCfg=None, _serialNumber=None, _component=None, _program=None, _vMajorProg=None, _vMinorProg=None, _vPatchProg=None, _vMajorSys=None, _vMinorSys=None, _vPatchSys=None, _unixTimeSeconds=None):
        self.meta_bytes += U16(_metaSize, array=1).tobytes()
        self.meta_bytes += FileMeta_CubeSpaceFileType(_fileType, array=1).tobytes()
        self.meta_bytes += U32(_fileSize, array=1).tobytes()
        self.meta_bytes += U32(_crc, array=1).tobytes()
        self.meta_bytes += U32(_flashAddress, array=1).tobytes()
        self.meta_bytes += U32(_nodeType, array=1).tobytes()
        self.meta_bytes += U16(_nodeProgram, array=1).tobytes()
        self.meta_bytes += U16(_vCfg, array=1).tobytes()
        self.meta_bytes += Text(_serialNumber, array=12).tobytes()
        self.meta_bytes += Text(_component, array=32).tobytes()
        self.meta_bytes += Text(_program, array=32).tobytes()
        self.meta_bytes += U8(_vMajorProg, array=1).tobytes()
        self.meta_bytes += U8(_vMinorProg, array=1).tobytes()
        self.meta_bytes += U16(_vPatchProg, array=1).tobytes()
        self.meta_bytes += U8(_vMajorSys, array=1).tobytes()
        self.meta_bytes += U8(_vMinorSys, array=1).tobytes()
        self.meta_bytes += U16(_vPatchSys, array=1).tobytes()
        self.meta_bytes += U32(_unixTimeSeconds, array=1).tobytes()

        return self.meta_bytes

    def from_bytes(self, meta_data):
        self.meta_dict = dict()
        parse_idx = 0
        for item in self.struct_items:
            if item['type'] == 'Text':
                value_convert = meta_data[parse_idx:parse_idx + item['size']].decode('utf-8')
                increment = item['size']
            else:
                value_convert = np.frombuffer(meta_data, dtype=item['nd_type'], count=item['size'], offset=parse_idx)[0]
                increment = np.dtype(item['nd_type']).itemsize

            parse_idx += increment

            self.meta_dict[item['name']] = value_convert

        return self.meta_dict

    def update_bytes(self, _meta_data, _metaSize=None, _fileType=None, _fileSize=None, _crc=None, _flashAddress=None, _nodeType=None, _nodeProgram=None, _vCfg=None, _serialNumber=None, _component=None, _program=None, _vMajorProg=None, _vMinorProg=None, _vPatchProg=None, _vMajorSys=None, _vMinorSys=None, _vPatchSys=None, _unixTimeSeconds=None):
        self.meta_bytes = _meta_data
        parse_idx = 0
        item_size = U16.tsize()
        if _metaSize is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U16(_metaSize, array=1).tobytes()
        parse_idx += item_size
        item_size = FileMeta_CubeSpaceFileType.tsize()
        if _fileType is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = FileMeta_CubeSpaceFileType(_fileType, array=1).tobytes()
        parse_idx += item_size
        item_size = U32.tsize()
        if _fileSize is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U32(_fileSize, array=1).tobytes()
        parse_idx += item_size
        item_size = U32.tsize()
        if _crc is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U32(_crc, array=1).tobytes()
        parse_idx += item_size
        item_size = U32.tsize()
        if _flashAddress is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U32(_flashAddress, array=1).tobytes()
        parse_idx += item_size
        item_size = U32.tsize()
        if _nodeType is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U32(_nodeType, array=1).tobytes()
        parse_idx += item_size
        item_size = U16.tsize()
        if _nodeProgram is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U16(_nodeProgram, array=1).tobytes()
        parse_idx += item_size
        item_size = U16.tsize()
        if _vCfg is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U16(_vCfg, array=1).tobytes()
        parse_idx += item_size
        item_size = 12
        if _serialNumber is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = Text(_serialNumber, array=12).tobytes()
        parse_idx += item_size
        item_size = 32
        if _component is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = Text(_component, array=32).tobytes()
        parse_idx += item_size
        item_size = 32
        if _program is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = Text(_program, array=32).tobytes()
        parse_idx += item_size
        item_size = U8.tsize()
        if _vMajorProg is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U8(_vMajorProg, array=1).tobytes()
        parse_idx += item_size
        item_size = U8.tsize()
        if _vMinorProg is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U8(_vMinorProg, array=1).tobytes()
        parse_idx += item_size
        item_size = U16.tsize()
        if _vPatchProg is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U16(_vPatchProg, array=1).tobytes()
        parse_idx += item_size
        item_size = U8.tsize()
        if _vMajorSys is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U8(_vMajorSys, array=1).tobytes()
        parse_idx += item_size
        item_size = U8.tsize()
        if _vMinorSys is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U8(_vMinorSys, array=1).tobytes()
        parse_idx += item_size
        item_size = U16.tsize()
        if _vPatchSys is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U16(_vPatchSys, array=1).tobytes()
        parse_idx += item_size
        item_size = U32.tsize()
        if _unixTimeSeconds is not None:
            self.meta_bytes[parse_idx:parse_idx + item_size] = U32(_unixTimeSeconds, array=1).tobytes()
        parse_idx += item_size

        return self.meta_bytes

    def size(self):
        return self.struct_size

