"""File meta data class generator."""
from pycparser import preprocess_file, c_ast
from pycparserext.ext_c_parser import GnuCParser
import os


_BASE_MAP_DICT = {
    'Boolean': 'np.uint32',
    'U8': 'np.uint8',
    'S8': 'np.int8',
    'U16': 'np.uint16',
    'S16': 'np.int16',
    'U32': 'np.uint32',
    'S32': 'np.int32',
    'U64': 'np.uint64',
    'S64': 'np.int64',
    'F32': 'np.float32',
    'F64': 'np.float64',
    'Text': 'np.chararray',
}


class FileStr(object):
    """Simple file string class."""

    def __init__(self):
        """Initialise file string as empty."""
        self.s = ''

    def add(self, indent_level, entry):
        """Add a line to the file string. Indent level must be maintained by caller."""
        self.s += 4 * ' ' * indent_level + entry + '\n'

    def newline(self):
        """Add an empty new line."""
        self.add(0, '')


def _parse_c_struct(hfile, gcc_path):
    """Parse the meta data structure in the c header file."""
    include_dir = os.path.dirname(hfile)  # All required files should be in the same directory as hfile

    text = preprocess_file(
        hfile,
        cpp_path=gcc_path,
        cpp_args=[
            '-E',
            r'-I'
            + os.path.join(include_dir),
            r'-D__attribute__(x)=',
            r'-D__asm__(x)=',
            r'-D__extension__=',
            r'-D__const=const',
            r'-D__inline__=inline',
            r'-D__inline=inline',
            r'-D__restrict=',
            r'-D__signed__=signed',
            r'-D__GNUC_VA_LIST',
            r'-D__gnuc_va_list=char'
        ]
    )

    parser = GnuCParser()  # Note use of GCC parser

    ast = parser.parse(text)

    meta_dict = dict()
    meta_dict['Enums'] = dict()
    meta_dict['Structs'] = dict()

    for symbol in ast.ext:
        if (isinstance(symbol, c_ast.Typedef) and isinstance(symbol.type.type, c_ast.Struct)):  # noqa: E129
            meta_dict['Structs'][symbol.name] = dict()
            for item in symbol.type.type:
                meta_dict['Structs'][symbol.name][item.name] = dict()

                itype = None
                size = None

                if isinstance(item.type, c_ast.ArrayDecl):
                    itype = item.type.type.type.names[0]
                    size = int(item.type.dim.value)
                else:
                    itype = item.type.type.names[0]
                    size = 1

                meta_dict['Structs'][symbol.name][item.name]['type'] = itype
                meta_dict['Structs'][symbol.name][item.name]['size'] = size
        elif (isinstance(symbol, c_ast.Typedef) and isinstance(symbol.type.type, c_ast.Enum)):
            meta_dict['Enums'][symbol.name] = dict()
            for val in symbol.type.type.values:
                try:
                    meta_dict['Enums'][symbol.name][val.name] = int(val.value.value)
                except Exception:
                    # Scaling
                    pass

    return meta_dict


def generate_meta_class(meta_file, gcc_path):
    """Generate a python class representation of file meta data sourced from fileMeta.h."""
    try:
        meta_dict = _parse_c_struct(meta_file, gcc_path)

        s = FileStr()

        s.add(0, 'import enum')
        s.add(0, 'import numpy as np')

        s.newline()

        # BASE TYPES #
        for type, np_type in _BASE_MAP_DICT.items():
            s.add(0, f'class {type}(object):')
            s.add(1, 'def __init__(self, value, array=1):')
            if type == 'Text':
                s.add(2, f'self.np_value = {np_type}((1,1), array)')
                s.add(2, 'self.np_value[:] = value')
            else:
                s.add(2, f'self.np_value = {np_type}(value)')
            s.newline()
            s.add(1, 'def tobytes(self):')
            s.add(2, 'return self.np_value.tobytes()')
            s.newline()
            s.add(1, 'def dtype():')
            s.add(2, f'return {np_type}')
            s.newline()
            s.add(1, 'def tsize():')
            if type == 'Text':
                s.add(2, 'return 1')
            else:
                s.add(2, f'return {np_type}().itemsize')
            s.newline()
            s.add(1, 'def size(self):')
            s.add(2, 'return self.np_value.itemsize')
            s.newline()

        s.newline()

        # ENUMS #
        for key in meta_dict['Enums']:
            s.add(0, f'class {key}(object):')
            s.add(1, 'class ThisEnum(enum.Enum):')
            s.add(2, 'NONE = None')
            for enum, value in meta_dict['Enums'][key].items():
                s.add(2, f'{enum} = {value}')
            s.newline()
            s.add(1, 'def __init__(self, value, array=1):')
            s.add(2, 'self.enum = self.ThisEnum(value)')
            s.newline()
            s.add(1, 'def value(self):')
            s.add(2, 'return self.enum.value')
            s.newline()
            s.add(1, 'def string(self):')
            s.add(2, 'return self.enum.__str__()')
            s.newline()
            s.add(1, 'def tobytes(self):')
            s.add(2, 'return np.int32(self.enum.value).tobytes()')
            s.newline()
            s.add(1, 'def dtype():')
            s.add(2, 'return np.int32')
            s.newline()
            s.add(1, 'def tsize():')
            s.add(2, 'return np.int32().itemsize')
            s.newline()

        s.newline()

        # STRUCTS #
        for key in meta_dict['Structs']:
            s.add(0, f'class {key}(object):')

            arg_string = ''
            len_struct = len(meta_dict['Structs'][key])
            for i, (item, value) in enumerate(meta_dict['Structs'][key].items()):
                arg_string += f'_{item}=None'
                if i < len_struct - 1:
                    arg_string += ', '

            s.add(1, 'def __init__(self):')
            s.add(2, 'self.struct_items = list()')
            s.add(2, 'self.meta_bytes = bytearray()')
            s.add(2, 'self.meta_dict = dict()')
            s.add(2, 'self.struct_size = 0')

            s.newline()

            for item, value in meta_dict['Structs'][key].items():
                s.add(2, 'new_item = dict()')
                s.add(2, f"new_item['name'] = '{item}'")
                s.add(2, f"new_item['type'] = '{value['type']}'")
                s.add(2, f"new_item['nd_type'] = {value['type']}.dtype()")
                s.add(2, f"new_item['size'] = {value['size']}")
                s.add(2, f'self.struct_size += {value["type"]}.tsize() * {value["size"]}')

                s.add(2, 'self.struct_items.append(new_item)')

            s.newline()

            # TO BYTES #
            s.add(1, f'def to_bytes(self, {arg_string}):')
            for item, value in meta_dict['Structs'][key].items():
                s.add(2, f'self.meta_bytes += {value["type"]}(_{item}, array={value["size"]}).tobytes()')
            s.newline()
            s.add(2, 'return self.meta_bytes')

            s.newline()

            # FROM BYTES #
            s.add(1, 'def from_bytes(self, meta_data):')
            s.add(2, 'self.meta_dict = dict()')
            s.add(2, 'parse_idx = 0')
            s.add(2, 'for item in self.struct_items:')
            s.add(3, "if item['type'] == 'Text':")
            s.add(4, "value_convert = meta_data[parse_idx:parse_idx + item['size']].decode('utf-8')")
            s.add(4, "increment = item['size']")
            s.add(3, 'else:')
            s.add(4, "value_convert = np.frombuffer(meta_data, dtype=item['nd_type'], count=item['size'], offset=parse_idx)[0]")
            s.add(4, "increment = np.dtype(item['nd_type']).itemsize")
            s.newline()
            s.add(3, 'parse_idx += increment')
            s.newline()
            s.add(3, "self.meta_dict[item['name']] = value_convert")

            s.newline()
            s.add(2, 'return self.meta_dict')

            s.newline()

            # UPDATE BYTES #
            s.add(1, f'def update_bytes(self, _meta_data, {arg_string}):')
            s.add(2, 'self.meta_bytes = _meta_data')
            s.add(2, 'parse_idx = 0')

            for item, value in meta_dict['Structs'][key].items():
                if value['type'] == 'Text':
                    s.add(2, f'item_size = {value["size"]}')
                else:
                    s.add(2, f'item_size = {value["type"]}.tsize()')
                s.add(2, f'if _{item} is not None:')
                s.add(3, f'self.meta_bytes[parse_idx:parse_idx + item_size] = {value["type"]}(_{item}, array={value["size"]}).tobytes()')
                s.add(2, 'parse_idx += item_size')
            s.newline()
            s.add(2, 'return self.meta_bytes')

            s.newline()

            # SIZE #
            s.add(1, 'def size(self):')
            s.add(2, 'return self.struct_size')

        s.newline()

        with open(f'{os.path.dirname(os.path.realpath(__file__))}/file_meta.py', 'w+') as fmeta:
            fmeta.write(s.s)

    except Exception:
        return False

    return True
