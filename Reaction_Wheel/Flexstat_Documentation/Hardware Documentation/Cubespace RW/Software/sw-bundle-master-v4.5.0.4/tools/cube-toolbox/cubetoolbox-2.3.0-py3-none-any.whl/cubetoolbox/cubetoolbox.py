"""#!/usr/bin/python."""
import os
import argparse
import hexdump
import io

import cubetoolbox.version as version
import cubetoolbox.nodecomms as nodecomms
import cubetoolbox.config as config
import cubetoolbox.files as files
import cubetoolbox.meta_generator as meta_gen

__version__ = version.__version__


################


def main(argv):
    """main."""
    parser = argparse.ArgumentParser(description='Cubespace ADCS Toolbox v' + __version__)
    parser.add_argument('--write-file', help='Single step flash CubeSpace file (.cs)')
    parser.add_argument('--write-config', help='Single step compile and flash config (.json)')
    parser.add_argument('--write-image', help='Single step flash application image (.bin)')

    parser.add_argument('--wrap-file', help='Wrap a file with CubeSpace metadata')
    parser.add_argument('--unwrap-file', help='Un-Wrap a CubeSpace file')
    parser.add_argument('--update-file', help='Update Meta Data of a CubeSpace file')
    parser.add_argument('--component-int', help='CubeSpace Component Enumeration e.g. NODE_DEF__NODES_CUBE_COMPUTER_5 as an integer value')
    parser.add_argument('--program-int', help='Component Program Enumeration e.g. NODE_DEF__PROGRAMS_CONTROL as an integer value')
    parser.add_argument('--component', help='CubeSpace Component e.g. cube-computer-5')
    parser.add_argument('--program', help='Component Program e.g. control-program')
    parser.add_argument('--program-version', help='Program Version e.g. <Major>.<Minor>.<Patch>')
    parser.add_argument('--system-version', help='System Version e.g. <Major>.<Minor>.<Patch>')
    parser.add_argument('--flash-address', help='Flash Offset for binary or config files in Hexidecimal')
    parser.add_argument('--rm', action='store_true', help='Remove file after operation')

    parser.add_argument('--generate-meta', action='store_true', help='Generate python class(s) from c-source meta data')
    parser.add_argument('--meta-file', help='C header file containing the Meta data structure')
    parser.add_argument('--gcc-path', help='Path to GCC')

    parser.add_argument('--config', help='JSON Config file to compile to flash blob')
    parser.add_argument('--list', action='store_true', help='List the availble interfaces')
    parser.add_argument('--verbose', action='store_true', help='Print more stuff')
    parser.add_argument('--info', action='store_true', help='Test the selected port for STM32 ROM bootloader presence')
    parser.add_argument('--read', action='store_true', help='Perform a read')
    parser.add_argument('--read-unprotect', action='store_true', help='Remove all read protection')
    parser.add_argument('--adv', action='store_true', help='Use slower more powerful read/write hook')
    parser.add_argument('--write', action='store_true', help='Perform a write')
    parser.add_argument('--write-unprotect', action='store_true', help='Remove all write protection')
    parser.add_argument('--autoerase', action='store_true', help='Erase flash pages written to automatically')
    parser.add_argument('--repeat', help='How many time to repeat write, incrementing the address')
    parser.add_argument('--address', help='Provide start address for read/write operation')
    parser.add_argument('--word', help='Provide integer to write')
    parser.add_argument('--size', help='Number of bytes to read/write')
    parser.add_argument('--set-dbank', help='Set dual-bank option bit(0 or 1)')
    parser.add_argument('--transport', help='Communication transport "uart" or "can"')
    parser.add_argument('--interface', help='Supply the interface name for the can transport. pcan, can0 etc.')
    parser.add_argument('--port', help='Supply the port name for uart transport. Use the --list command to see available ports')
    parser.add_argument('--output', help='Read output will go into this file in binary format')
    parser.add_argument('--input', help='Write input will read input file in binary format')
    parser.add_argument('--erase', help='0: Everything, 1: Bank 1, 2: Bank 2')
    parser.add_argument('--epage', help='Erase Page number - see info')
    parser.add_argument('--jump-to', action='store_true', help='Address to run (must point to vector table)')
    parser.add_argument('--read-identity', action='store_true', help='Read the production time fused node identity of the unit')
    parser.add_argument('--write-identity', action='store_true',
                        help='Burn the production time node identity of the unit')
    parser.add_argument('--read-serial', action='store_true', help='Read the production time fused serial number of the unit')
    parser.add_argument('--write-serial', action='store_true',
                        help='Burn the production time serial number of the unit')
    parser.add_argument('--identity', help='Identity to program to node, e.g cube-computer-5')
    parser.add_argument('--serial', help='Production time serial of node, e.g CS21001')

    parser.add_argument('--crc32', help='Calculate the 32-bit crc of file')
    parser.add_argument('--crc-exclude', action='store_true',
                        help='Signals that the last 4-bytes of the input file should not be used during the crc32 calculation')

#    parser.add_argument('--ndpath', help='Nodedef files location')
#    parser.add_argument('--ndlist', action='store_true', help='Nodedef nodes supported')

    args = parser.parse_args(argv)
    args_dict = vars(args)

    """
    ########################################################################################
    ## CONVERT OPTION ALIASES
    ########################################################################################
    """
    if args.crc32 is not None:
        return files.crc32(args.verbose, input=args.crc32, output=args.output, crc_exclude=args.crc_exclude)

    if args.generate_meta is True:
        return meta_gen.generate_meta_class(args.meta_file, args.gcc_path)

    if args.wrap_file is not None:
        return files.wrap(args.verbose,
                          args.wrap_file, args.rm,
                          flash_address=args.flash_address,
                          component_int=args.component_int, program_int=args.program_int,
                          component=args.component, program=args.program,
                          program_version=args.program_version, system_version=args.system_version)
    elif args.unwrap_file is not None:
        return files.unwrap(args.verbose,
                            args.unwrap_file, args.rm)
    elif args.update_file is not None:
        return files.update(args.verbose,
                            args.update_file,
                            flash_address=args.flash_address,
                            component_int=args.component_int, program_int=args.program_int,
                            component=args.component, program=args.program,
                            program_version=args.program_version, system_version=args.system_version)

    print('Processing ...')

    comms = nodecomms.NodeComms()

    if args.list:
        comms.list_interfaces()
        return True

    if args.verbose:
        comms.set_verbose()

    """
    ########################################################################################
    ## COMMS OPERATIONS
    ########################################################################################
    """

    if args.transport == 'can':
        if args.interface is not None:
            if args.interface == 'pcan':
                if not comms.check_driver('PCAN_USB'):
                    print('PCAN_USB Driver not found.')
                    return False
            else:
                if not comms.check_can_interface(args.interface):
                    print(f'Interface not found: {args.interface}')
                    return False
            # The CAN interface hard-codes a baud rate at runtime, see _wake()
            comms.set_transport(transport=args.transport, can_interface=args.interface, can_baud=None)
            if not comms.getstate():
                if not args.read_unprotect:
                    print('Get State Failed.')
                    return False
                else:   # special case: ignore get state failed (because option bytes could not be read)
                    print('For read-unprotect, ignore Get State Failure')

        else:
            print('--interface not specified. Unable to connect to device')
            return False

    elif args.transport == 'uart':
        if args.port is not None:
            comms.set_transport(transport='uart', com_port=args.port)
            if not comms.getstate():
                if not args.read_unprotect:
                    print('Get State Failed.')
                    return False
                else:   # special case: ignore get state failed (because option bytes could not be read)
                    print('For read-unprotect, ignore Get State Failure')
        else:
            print('--port not specified. Unable to connect to device')
            return False
    else:
        print('--transport not specified. Either uart or can')
        return False

    if args.info:
        comms.print_state()

    if args.read_unprotect:
        return comms.read_unprotect()

    if args.write_file is not None or args.erase is not None:
        if comms.write_unprotect() is False:
            return False
    elif args.write_unprotect:
        return comms.write_unprotect()

    is_config = False

    # Unpack write-config combo command
    if args.write_config is not None:
        if args.address is not None:
            addr = comms.translate_address(int(args.address, 0))  # Translate address if BFB2 is set

            if int(args.address, 0) < 0x8000000 or int(args.address, 0) >= (0x8000000 + 0x200000):
                print('Error: Not a valid Flash address for autoerase')
                return False
            else:
                is_config = True
                args_dict['config'] = args.write_config
                args_dict['output'] = args.write_config + '.bin'
                args_dict['autoerase'] = True
                args_dict['write'] = True
                args_dict['address'] = args.address
                args_dict['input'] = args.write_config + '.bin'
        else:
            print('Error: User must specify config address')
            return False

    """
    ########################################################################################
    ## CONFIG COMPILE
    ########################################################################################
    """
    if args.config is not None:
        if args.output is not None:
            print(f'Compiling JSON Config: {args.config}')
            result = config.compile(args.config, args.output)
            print(f'Flash Config Binary  : {args.output}')
            if args.write_config is None:
                return result
        else:
            print(f'Compiling JSON Config: {args.config}')
            result = config.compile(args.config, args.config + '.bin')
            print(f'Flash Config Binary  : {args.config}.bin')
            if args.write_config is None:
                return result

    # Unpack write-image combo command
    if args.write_image is not None:
        args_dict['autoerase'] = True
        args_dict['input'] = args.write_image
        args_dict['write'] = True
        args_dict['address'] = comms.translate_address(args.address)  # Translate address if BFB2 is set

    # Write .cs file (contains Meta-data)
    if args.write_file is not None:
        if files.is_file_type(args.verbose, args.write_file, 'cfg'):
            is_config = True
            files.unwrap(args.verbose, args.write_file, False)
            args_dict['autoerase'] = True
            args_dict['input'] = f'{args.write_file}.unwrapped'
            args_dict['write'] = True
            # Translate address if BFB2 is set
            args_dict['address'] = hex(comms.translate_address(files.get_parameter(args.verbose, args.write_file, 'flashAddress')))
        elif files.is_file_type(args.verbose, args.write_file, 'bin'):
            files.unwrap(args.verbose, args.write_file, False)
            args_dict['autoerase'] = True
            args_dict['input'] = f'{args.write_file}.unwrapped'
            args_dict['write'] = True
            # Translate address if BFB2 is set
            args_dict['address'] = hex(comms.translate_address(files.get_parameter(args.verbose, args.write_file, 'flashAddress')))
        else:
            print(f'Invalid file input: {args.write_file}')
            return False

    """
    ########################################################################################
    ## ERASE REQUEST
    ########################################################################################
    """
    if args.erase is not None:
        if int(args.erase) == 0:
            print('Flash Erase all ...')
        else:
            print(f'Flash Erase bank: {str(int(args.erase))}...')

        if not comms.erase_all(int(args.erase)):
            print('Flash Erase Failed.')
            return False

        comms.clear_dual_bank_boot()

        print('Flash Erase complete')

    if args.epage is not None:
        print(f'Flash Erase page: {str(int(args.epage))}...')

        if not comms.erase(int(args.epage), 1):
            print('Flash Erase Failed.')
            return False

        print('Flash Erase complete')

    if args.autoerase is True and args.write is True and args.address is not None:

        # Are we targetting flash memory?
        if int(args.address, 0) < 0x8000000 or int(args.address, 0) >= (0x8000000 + 0x200000):
            print('Error: Not a valid Flash address for autoerase')
            return False

        # Try to work out the block size
        if args.input is not None:
            size = os.stat(str(args.input)).st_size
        elif args.word is not None:
            size = 4
        else:
            print('Error: Flash autoerase does not know the size of the write operation')
            return False

        if args.repeat is not None:
            repeat = int(args.repeat)
        else:
            repeat = 1

        # Take repeats into account
        addr = int(args.address, 0) - 0x8000000
        size = size * repeat
        pagesize = comms.flash_page_size()
        spage = int(addr / pagesize)
        epage = int((addr + size + pagesize - 1) / pagesize)

        print(f'Flash Auto Erase Page: {str(spage)} - {str(epage-1)}')
        print(f'Address: {hex(int(args.address, 0))}')
        print(f'Size: {str(size)} bytes (including repeat)')

        if not comms.erase(spage, epage - spage):
            print('Flash Erase failed')
            return False

        print('Flash Erase complete')

    """
    ########################################################################################
    ## WRITE REQUEST
    ########################################################################################
    """
    if args.write:
        if comms.get_transport() is not None and args.address is not None:
            if args.input is not None:
                f = io.open(str(args.input), 'rb')
                if f is not None:
                    data = bytearray(f.read())

                    num_to_append = 0

                    if is_config is True:
                        #  Must be word alligned, Otherwise Cube-Toolbox doesn't want to flash the config
                        num_to_append = 4 - (len(data) % 4)

                        if num_to_append == 4:
                            num_to_append = 0

                        for i in range(num_to_append):
                            data += b'\00'

                    if args.repeat is not None:
                        repeat = int(args.repeat)
                    else:
                        repeat = 1

                    size = os.stat(str(args.input)).st_size
                    print(f'Binary file read: {str(args.input)}')
                    print(f'Size: {str(size)} bytes')
                    print(f'Padding: {str(num_to_append)} bytes')
                    print(f'Address: {hex(int(args.address, 0))}')
                    print(f'Repeat: {str(repeat)}')
                    print('Writing memory ...')

                    if not comms.write(int(args.address, 0), data, repeat):
                        print('Flash Write Failed.')
                        return False

                    f.close()
                    print('Memory Write complete')

                else:
                    print(f'Error: Supplied filename not found ({str(args.input)})')
                    return False

            elif args.word is not None:

                if args.repeat is not None:
                    repeat = int(args.repeat)
                else:
                    repeat = 1
                data = bytearray(int(args.word, 0).to_bytes(4, 'little'))

                print(f'Size: {str(len(data))} bytes')
                print(f'Address: {hex(int(args.address, 0))}')
                print(f'Repeat: {str(repeat)}')
                print('Writing memory ...')

                if not comms.write(int(args.address, 0), data, repeat):
                    print('Flash Write Failed.')
                    return False

                print('Memory Write complete')

            else:
                print('Error: You must supply a filename or word value to be written')
                return False

        else:
            print('Error: You must supply a valid port name and address')
            return False

    """
    ########################################################################################
    ## READ REQUEST
    ########################################################################################
    """
    if args.read:
        if comms.get_transport() is not None and args.address is not None and args.size is not None:
            if args.adv:
                print('Advanced Read: YES')
                print(f'Size: {str(int(args.size, 0))} bytes')
                print(f'Address: {hex(int(args.address, 0))}')
                print('Reading memory ...')
                addr = int(args.address, 0)
                if addr & 0x3:
                    print('Error: Advanced read must be addr aligned to 4')
                    return True

                size = int(args.size, 0)
                if size & 0x3:
                    print('Error: Advanced read must be size multiple of 4')
                    return True

                data = bytearray([])
                for i in range(0, size, 4):
                    data += comms.adv_read(int(args.address, 0) + i)
            else:
                print(f'Size: {str(int(args.size, 0))} bytes')
                print(f'Address: {hex(int(args.address, 0))}')
                print('Reading memory ...')
                data = comms.read(int(args.address, 0), int(args.size, 0))

            if len(data) == 0:
                print('Error: Read failed')
                return False

            if args.output is not None:
                f = io.open(str(args.output), 'wb')
                if f is not None:
                    f.write(data)
                    f.close()
                print(f'Binary file written: {str(args.output)}')
            else:
                hexdump.hexdump(data)
        else:
            print('Error: You must supply a valid port name, address and byte size')
            return False

        """
    ########################################################################################
    ## OPTION BYTE OPERATIONS
    ########################################################################################
    """
    if args.set_dbank is not None:
        if (args.set_dbank == '0') or (args.set_dbank == '1'):
            print(f'Setting DBANK: {args.set_dbank}')
            return comms.flash_set_dual_bank(int(args.set_dbank))
        else:
            print(f'Set value for DBANK must be 0 or 1. Set value is: {args.set_dbank}')
            return False

    """
    ########################################################################################
    ## Read identity
    ########################################################################################
    """
    if args.read_identity is True:
        print('Reading Node identifier...')
        node, revision = comms.read_identity()

        if node and revision:
            print(f'Connected to {node}-{revision}')
            return f'{node}-{revision}'
        elif node == 0xFF:
            print('Error: No identifier programmed')
            return None
        else:
            print('Error: OTP Corrupt')
            return None
    """
    ########################################################################################
    ## Read serial
    ########################################################################################
    """
    if args.read_serial is True:
        print('Reading Node serial...')
        serial = comms.read_serial()

        if len(serial) != 0:
            if ord(serial[0]) == 255:
                print('Serial not yet fused')
                return None
            else:
                print('Serial: ' + serial)
                return serial
        else:
            print('Invalid (zero) serial already fused')
            return None

    """
    ########################################################################################
    ## Write identity
    ########################################################################################
    """
    if args.write_identity is True:
        if args.identity is not None:
            print('Reading Node identifier...')
            node, revision = comms.read_identity()

            if (node == 0xFF) and (not revision):
                comms.write_identity(args.identity)

                print('Reading Node identifier...')
                node, revision = comms.read_identity()

                if node and revision:
                    print(f'Connected to {node}-{revision}')
                else:
                    print('Error: Verification read failed')
                    return False
            else:
                print(f'Error: Could not assign ID to {node}-{revision}, run --read-identity for more information')
                return False
        else:
            print('Error: Identity not set, please with --identity')
            return False

    """
    ########################################################################################
    ## Write serial
    ########################################################################################
    """
    if args.write_serial is True:
        if args.serial is not None:
            serial = comms.read_serial()

            if len(serial) != 0:
                if ord(serial[0]) == 255:
                    comms.write_serial(args.serial)
                else:
                    print('Serial already fused')
            else:
                print('Invalid (zero) serial already fused')

            print('Reading Node serial...')
            serial = comms.read_serial()
            print('Serial: ' + serial)

        else:
            print('Error: Serial not set, please with --serial')
            return False

    """
    ########################################################################################
    ## RUN REQUEST
    ########################################################################################
    """

    if args.jump_to is True and args.address is not None:
        print('Image Entry: ' + hex(int(args.address, 0)))
        print('Program started ...')
        if not comms.execute(int(args.address, 0)):
            return False

    """
     ########################################################################################
     ## GLOBAL RETURN
     ########################################################################################
     """
    comms.close()  # Ensure comms channels are closed

    """
     ########################################################################################
     ## CLEANUP
     ########################################################################################
     """
    if args.write_file is not None:
        os.remove(args_dict['input'])  # This should be an unwrapped file

    return True
