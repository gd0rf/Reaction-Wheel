"""
cube-toolbox.

nodecomms.py
"""
import sys
import serial.tools.list_ports
import time
import math
import os
import builtins
import json
import struct
import can
import can.interfaces.pcan as pcan


class InputIdentityFailure(Exception):
    """Exceptions."""

    pass


class InputValue(Exception):
    """Exceptions."""

    pass


class NodedefIOFailure(Exception):
    """Exceptions."""

    pass


class CommsFailure(Exception):
    """Exceptions."""

    pass


class PortFailure(Exception):
    """Exceptions."""

    pass


class NodeComms(object):
    """NodeComms Class handles communications of all transports."""

    MSG_ID_ACK = 0x79
    MSG_ID_NACK = 0x1F

    MSG_ID_GET = 0x00
    MSG_ID_GET_VERSION = 0x01
    MSG_ID_GET_ID = 0x02
    MSG_ID_SPEED = 0x03
    MSG_ID_READ_MEMORY = 0x11
    MSG_ID_GO = 0x21
    MSG_ID_WRITE_MEMORY = 0x31
    MSG_ID_ERASE = 0x43
    MSG_ID_ERASE_EXTENDED = 0x44
    MSG_ID_WRITE_PROTECT = 0x63
    MSG_ID_WRITE_UNPROTECT = 0x73
    MSG_ID_READOUT_PROTECT = 0x82
    MSG_ID_READOUT_UNPROTECT = 0x92

    MSG_ID_CAN_SYNC = 0x79

    FLASH_OPTR__MASK_BFB2 = 0x100000
    FLASH_OPTR__MASK_DBANK = 0x400000

    CAN_BAUD_TRANSLATION = {
        None: 125000,
        '1': 125000,
        '2': 250000,
        '3': 500000,
        '4': 1000000
    }

    # OTP allocation
    # Note: Entries are allocated as 32-byte blocks
    # to allow for future changes to one entry type
    OTP_OFFSET_NODE_ID_NUMBER = 0x0              # SIZE = 32 bytes (256 bits)
    OTP_OFFSET_NODE_PRODUCTION_SERIAL = 0x20     # SIZE = 32 bytes (256 bits)

    def __init__(self):
        """Initialize NodeComms Class."""
        # otp globals

        self.gotpaddress = 0x1FFF7000
        self.gotpsize = 1024

        # ROM hook code

        self.ghookaddress = 0x20004000
        self.ghookresult = 0x20004100
        self.ghookread = bytearray([
            0x00, 0x41, 0x00, 0x20,
            0x09, 0x40, 0x00, 0x20,
            0x05, 0x4b, 0x06, 0x4c,
            0x24, 0x68, 0x1c, 0x60,
            0x05, 0x49, 0x06, 0x48,
            0x88, 0x60, 0x01, 0x68,
            0x8d, 0x46, 0x40, 0x68,
            0x00, 0x47, 0x00, 0x00,
            0x00, 0x41, 0x00, 0x20,
            0x04, 0x00, 0xff, 0x1f,
            0x00, 0xed, 0x00, 0xe0,
            0x00, 0x00, 0xff, 0x1f
        ])

        self.transport = None
        self.com_port = None
        self.can_interface = None
        self.interface = None
        self.verbose = False

        self.gflashorigin = 0x08000000
        self.gversion = None
        self.gcaps = None
        self.goptions = None
        self.gchip = None
        self.gchipname = None
        self.grdp = None
        self.gdbank = None
        self.gdbankboot = None
        self.gusropts = None
        self.gfsize = None
        self.gdfpage = None
        self.gfpage = None
        self.gchipfamily = None
        self.gwrpbank1a = None
        self.gwrpbank1b = None
        self.gwrpbank2a = None
        self.gwrpbank2b = None

        self.can_baud_pcan = None

        # Avoid printing inevitable bus heavy errors prior to syncing with the right baud rate
        can.util.set_logging_level(level_name='critical')

    def _node_print(self, msg):
        """Control verbose prints."""
        if self.verbose:
            print(msg, flush=True)

    def _open(self):
        """Open an interface."""
        if self.interface is not None:
            self._close()

        if self.transport == 'uart':
            try:
                self.interface = serial.Serial(self.com_port, 115200, timeout=2,
                                               parity=serial.PARITY_EVEN,
                                               stopbits=serial.STOPBITS_ONE,
                                               bytesize=serial.EIGHTBITS,
                                               xonxoff=False,
                                               rtscts=False,
                                               dsrdtr=False)
            except (ValueError, serial.SerialException):
                return False

        elif self.transport == 'can':
            try:
                if self.interface is None:
                    if self.can_interface == 'pcan':
                        self.interface = pcan.PcanBus(channel='PCAN_USBBUS1', state=can.bus.BusState.ACTIVE,
                                                      bitrate=self.CAN_BAUD_TRANSLATION[self.can_baud_pcan])
                    else:
                        ret = os.system(f'sudo ip link set {self.can_interface} down > /dev/null 2>&1')

                        if ret == 0:
                            ret = os.system(f'sudo ip link set {self.can_interface} up type can '
                                            f'bitrate {self.CAN_BAUD_TRANSLATION[self.can_baud_pcan]} > /dev/null 2>&1')

                        if ret == 0:
                            ret = os.system(f'sudo ip link set {self.can_interface} txqueuelen 1000 > /dev/null 2>&1')

                        if ret == 0:
                            self.interface = can.interface.Bus(channel=self.can_interface, bustype='socketcan')
                        else:
                            print(f'Failed to setup ip link for {self.can_interface}. User must have sudo privileges.')
                            return False

                    self.interface.set_filters([
                        {'can_id': self.MSG_ID_ACK, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_NACK, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_GET, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_GET_VERSION, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_GET_ID, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_SPEED, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_READ_MEMORY, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_GO, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_WRITE_MEMORY, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_ERASE, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_WRITE_PROTECT, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_WRITE_UNPROTECT, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_READOUT_PROTECT, 'can_mask': 0xffff, 'extended': False},
                        {'can_id': self.MSG_ID_READOUT_UNPROTECT, 'can_mask': 0xffff, 'extended': False}
                    ])

                    time.sleep(0.1)

            except (PortFailure, pcan.pcan.PcanError):
                print('PCAN Initialization Failed. Likely unconnected or too many instances.')
                return False

        self._node_print('Port opened')

        return True

    def _close(self):
        """Close an interface."""
        if self.transport == 'uart':
            try:
                if self.interface is not None:
                    self.interface.close()
            except PortFailure:
                return False
        elif self.transport == 'can':
            try:
                if self.interface is not None:
                    self.interface.shutdown()  # CAN bus uses shutdown method

                    if self.can_interface == 'can':
                        ret = os.system(f'sudo ip link set {self.can_interface} down > /dev/null 2>&1')
                        if ret != 0:
                            return False

                    time.sleep(0.1)
            except PortFailure:
                return False

        self.interface = None
        self._node_print('Port closed')

        return True

    def _send_uart(self, data):
        """Send data on the UART interface."""
        try:
            self.interface.write(data)
        except PortFailure:
            return False

    def _send_can(self, data, fid):
        """Send data on the CAN interface."""
        try:
            msg = can.Message(arbitration_id=fid, is_extended_id=False, data=data)
            self.interface.send(msg=msg, timeout=1)
        except (PortFailure, pcan.pcan.PcanError):
            return False

    def _receive_uart(self, size):
        """Receive data on the UART interface."""
        try:
            rx_data = self.interface.read(size=size)
        except PortFailure:
            return None

        return rx_data

    def _receive_can(self, fid, size, timeout):
        """Receive data on the CAN interface."""
        try:
            remainder = 1 if size % 8 > 0 else 0
            read_count = int(size / 8) + remainder
            recv_data = b''
            while read_count > 0:
                read_count -= 1
                msg = self.interface.recv(timeout=timeout)
                if msg is not None and not msg.is_error_frame and msg.arbitration_id == fid:
                    recv_data += msg.data
                else:
                    return b''

            return recv_data

        except (PortFailure, pcan.pcan.PcanError):
            return b''

    def _reset_input_buffer(self):
        """Reset Input buffer."""
        if self.transport == 'uart':
            try:
                self.interface.reset_input_buffer()
            except PortFailure:
                return None
        elif self.transport == 'can':
            if self.can_interface == 'pcan':
                try:
                    self.interface.reset()
                except PortFailure:
                    return None

    def _can_sync_with_baud(self, baud=None):
        self._node_print(f'Trying CAN sync with baud: {self.CAN_BAUD_TRANSLATION[baud]}')

        try:
            self._close()
            self.set_transport(transport='can', can_interface=self.can_interface, can_baud=baud)
            opened = self._open()

            if opened is False:
                raise PortFailure

            retry_count = 3
            found = False
            while retry_count > 0 and found is False:
                self._send_can([], fid=self.MSG_ID_CAN_SYNC)

                ack, nack = self._search_ack(fid=self.MSG_ID_CAN_SYNC, timeout=0.1)
                if ack or nack:
                    found = True
                else:
                    retry_count -= 1
                    # Close and re-open port to clear bus errors
                    self._close()
                    self._open()

            # Reset the can warning counter after STM wake up
            if found:
                self._close()
                self._open()

            return found

        except PortFailure:
            self._close()
            return False

    def _search_ack(self, fid, num_ack=1, num_nack=1, timeout=0.3):
        """Search for ACK and NACK for given fid."""
        count_limit = 5
        ack_count = 0
        nack_count = 0
        found_ack = False
        found_nack = False
        while count_limit > 0 and not found_ack and not found_nack:
            data = self._receive_can(fid=fid, size=1, timeout=timeout)
            if len(data) > 0 and data[0] == self.MSG_ID_ACK:
                ack_count += 1
                if ack_count == num_ack:
                    found_ack = True
            elif len(data) > 0 and data[0] == self.MSG_ID_NACK:
                nack_count += 1
                if nack_count == num_nack:
                    found_nack = True
            else:
                count_limit -= 1

        return found_ack, found_nack

    def _convert_size(self, size_bytes):
        """Convert Size."""
        if size_bytes == 0:
            return '0B'
        size_name = ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB')
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return '%s %s' % (s, size_name[i])

    def _wake(self):
        """Wake."""
        self._node_print('Detecting (10 seconds)')
        found = False
        shutdown = False
        timeout = 10 + int(time.time())
        while not shutdown and not found:

            # Make sure nothing is currently in the buffer
            self._reset_input_buffer()

            if self.transport == 'uart':
                # Write magic byte to select ROM bootloader peripheral
                wakeup = bytearray([0x7F])
                self._send_uart(wakeup)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) != 0:
                    if reply[0] == 0x79:
                        # OK we woke it
                        found = True
                        self._node_print('Rom bootloader woken on this port')
                    elif reply[0] == 0x1F:
                        # It is already awake
                        found = True
                        self._node_print('Rom bootloader already awake on this port')

            elif self.transport == 'can':
                # First try 500kbps, because it is our hard coded baud rate
                if self._can_sync_with_baud('3'):
                    self._node_print(f'Rom bootloader woken CAN {self.CAN_BAUD_TRANSLATION["3"]}bps')
                    found = True
                elif self._can_sync_with_baud('1'):
                    self._node_print(f'Rom bootloader woken CAN {self.CAN_BAUD_TRANSLATION["1"]}bps')
                    if self.write_can_speed('3'):
                        found = True

            if int(time.time()) > timeout:
                shutdown = True

        if not found:
            print('')
            print('Node not found. Please check wiring and BOOT pin (powercycle with BOOT high)')
            return False
        else:
            return True

    def _info(self):
        """Info."""
        data = 0
        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            infocmd = bytearray([self.MSG_ID_GET, 0xFF])
            self._send_uart(infocmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=2)
            if len(reply) != 0:
                if reply[0] == self.MSG_ID_ACK:
                    data = int(reply[1]) + 2
                else:
                    print('Get command returned unexpected reply')
                    return False
            else:
                print('Get command returned no reply')
                return False

            if data != 0:
                reply = self._receive_uart(size=data)
                if len(reply) != data or int(reply[data - 1]) != self.MSG_ID_ACK:
                    print('Get command reply invalid')
                    return False
                else:
                    self.gversion = str((reply[0] & 0xF0) >> 4) + '.' + str(reply[0] & 0x0F)
                    self.gcaps = reply[1:data - 1]

        elif self.transport == 'can':
            self._send_can([], self.MSG_ID_GET)

            ack, nack = self._search_ack(fid=self.MSG_ID_GET)
            if ack and not nack:
                rx_data = self._receive_can(fid=self.MSG_ID_GET, size=1, timeout=0.3)
                if len(rx_data) > 0:
                    data = rx_data[0]  # Receive number of bytes

                rx_data = self._receive_can(fid=self.MSG_ID_GET, size=1, timeout=0.3)
                if len(rx_data) > 0:
                    self.gversion = str((rx_data[0] & 0xF0) >> 4) + '.' + str(rx_data[0] & 0x0F)  # Receive version

                # Supported commands - Bytes are received one message at a type
                caps = list()
                for i in range(data):
                    rx_data = self._receive_can(fid=self.MSG_ID_GET, size=1, timeout=0.3)
                    if len(rx_data) > 0:
                        caps.append(rx_data[0])

                ack, nack = self._search_ack(fid=self.MSG_ID_GET)
                if ack and not nack:
                    self.gcaps = caps
                else:
                    self._node_print('Get Command No Ack received.')
                    return False
            else:
                print('Get command returned no reply')
                return False
        else:
            self._node_print('Transport not specified.')
            return False

        return True

    def _options(self):
        """Get option bytes."""
        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            optcmd = bytearray([self.MSG_ID_GET_VERSION, 0xFE])
            self._send_uart(optcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=5)
            if len(reply) != 0:
                if reply[0] == self.MSG_ID_ACK and reply[4] == self.MSG_ID_ACK:
                    self.goptions = reply[2:4]
                else:
                    print('Option command returned unexpected reply')
                    return False
            else:
                print('Option command returned no reply')
                return False

        elif self.transport == 'can':
            self._reset_input_buffer()

            self._send_can([], self.MSG_ID_GET_VERSION)

            ack, nack = self._search_ack(fid=self.MSG_ID_GET_VERSION)
            if ack and not nack:
                rx_data = self._receive_can(fid=self.MSG_ID_GET_VERSION, size=1, timeout=0.3)

                if len(rx_data) == 0:
                    self._node_print('Option command failed')
                    return False  # Don't use this bootloader version

                rx_data = self._receive_can(fid=self.MSG_ID_GET_VERSION, size=1, timeout=0.3)  # Receive dummy bytes
                if len(rx_data) > 0:
                    self.goptions = rx_data[0:1]
                else:
                    self._node_print('Option command failed')

                ack, nack = self._search_ack(fid=self.MSG_ID_GET_VERSION)
                if not ack:
                    self._node_print('Option command No Ack received.')
                    return False
            else:
                print('Option command returned no reply')
                return False

        else:
            self._node_print('Transport not specified.')
            return False

        return True

    def _chip(self):
        """Get chip ID."""
        chip = 0x00
        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            chipcmd = bytearray([self.MSG_ID_GET_ID, 0xFD])
            self._send_uart(chipcmd)

            # See if we got a reply from the ROM bootloader
            data = 0
            reply = self._receive_uart(size=2)
            if len(reply) != 0:
                if reply[0] == self.MSG_ID_ACK:
                    data = int(reply[1]) + 2
                else:
                    print('Chip command returned unexpected reply')
                    return False
            else:
                print('Chip command returned no reply')
                return False

            if data != 0:
                reply = self._receive_uart(size=data)
                if len(reply) != data or int(reply[data - 1]) != self.MSG_ID_ACK:
                    print('Chip command reply invalid')
                    return False
                else:
                    chip = hex((reply[1] & 0xFF) | ((reply[0] << 8) & 0xFF00))

        elif self.transport == 'can':
            self._reset_input_buffer()

            self._send_can([], self.MSG_ID_GET_ID)

            ack, nack = self._search_ack(fid=self.MSG_ID_GET_ID)
            if ack and not nack:
                rx_data = self._receive_can(fid=self.MSG_ID_GET_ID, size=2, timeout=0.3)  # Read PID
                if len(rx_data) > 0:
                    chip = hex((rx_data[1] & 0xFF) | ((rx_data[0] << 8) & 0xFF00))

                ack, nack = self._search_ack(fid=self.MSG_ID_GET_ID)
                if not ack:
                    self._node_print('ID command No Ack received.')
                    return False
            else:
                print('ID command returned unexpected reply')
                return False
        else:
            self._node_print('Transport not specified.')
            return False

        self.gchip = chip

        if self.gchip == '0x470':
            self.gchipname = 'STM32L4Rxxx / STM32L4Sxxx'
            self.gchipfamily = 'L4+'

            self.gfpage = 8192
            self.gdfpage = 4096

        elif self.gchip == '0x471':
            self.gchipname = 'STM32L4Pxxx / STM32L4Qxxx'
            self.gchipfamily = 'L4+'

            self.gfpage = 8192
            self.gdfpage = 4096

        elif self.gchip == '0x464':
            self.gchipname = 'STM32L41xxx'
            self.gchipfamily = 'L4'
            self.gfpage = 2048
        elif self.gchip == '0x435':
            self.gchipname = 'STM32L43xxx'
            self.gchipfamily = 'L4'
            self.gfpage = 2048
        elif self.gchip == '0x462':
            self.gchipname = 'STM32L45xxx'
            self.gchipfamily = 'L4'
            self.gfpage = 2048
        else:
            self.gchipname = 'Unknown'

        return True

    def _jump(self, byteaddr):
        """Execute code."""
        self._node_print(f'Jump to Address: {byteaddr}')
        # Send jump address
        a0 = (byteaddr & 0xFF000000) >> 24
        a1 = (byteaddr & 0x00FF0000) >> 16
        a2 = (byteaddr & 0x0000FF00) >> 8
        a3 = (byteaddr & 0x000000FF)

        # Aligned?
        if byteaddr & 0x3:
            print('Jump address must be 4 byte aligned')
            return False

        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            jumpcmd = bytearray([self.MSG_ID_GO, 0xDE])
            self._send_uart(jumpcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Jump command returned unexpected reply')
                return None
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Jump command returned unexpected reply')
                    return None

            crc = (a0 ^ a1 ^ a2 ^ a3) & 0xFF

            jumpcmd = bytearray([a0, a1, a2, a3, crc])
            self._send_uart(jumpcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Jump command returned unexpected reply')
                return None
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Jump command returned unexpected reply')
                    return None

        elif self.transport == 'can':
            go_cmd_data = bytearray([a0, a1, a2, a3])
            self._send_can(data=go_cmd_data, fid=self.MSG_ID_GO)

            # STM likes a delay here
            time.sleep(0.05)  # This value was thumb sucked

            ack, nack = self._search_ack(fid=self.MSG_ID_GO)
            if not ack:
                self._node_print('GO Command no Ack')
                return False
        else:
            self._node_print('Transport not specified.')
            return False

        return True

    def _read_block(self, byteaddr, bytesize):
        """Read up to 255 bytes."""
        # Send read address
        a0 = (byteaddr & 0xFF000000) >> 24
        a1 = (byteaddr & 0x00FF0000) >> 16
        a2 = (byteaddr & 0x0000FF00) >> 8
        a3 = (byteaddr & 0x000000FF)

        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            readcmd = bytearray([self.MSG_ID_READ_MEMORY, 0xEE])
            self._send_uart(readcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Read command returned unexpected reply')
                return None
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Read command returned unexpected reply')
                    return None

            crc = (a0 ^ a1 ^ a2 ^ a3) & 0xFF

            readcmd = bytearray([a0, a1, a2, a3, crc])
            self._send_uart(readcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Read command returned unexpected reply')
                return None
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Read command returned unexpected reply')
                    return None

            # Send size in bytes
            s = bytesize
            s = s - 1
            crc = (~s) & 0xFF

            readcmd = bytearray([s, crc])
            self._send_uart(readcmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Read command returned unexpected reply')
                return None
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Read command returned unexpected reply')
                    return None
            if s != 0:
                reply = self._receive_uart(size=s + 1)
                if len(reply) != (s + 1):
                    print('Read command reply length incorrect')
                    return None

        elif self.transport == 'can':
            read_cmd_data = bytearray([a0, a1, a2, a3, bytesize - 1])
            self._send_can(data=read_cmd_data, fid=self.MSG_ID_READ_MEMORY)

            ack, nack = self._search_ack(fid=self.MSG_ID_READ_MEMORY)
            if ack and not nack:
                reply = self._receive_can(fid=self.MSG_ID_READ_MEMORY, size=bytesize, timeout=0.3)
                if len(reply) != bytesize:
                    self._node_print('Failed to read memory.')
                    return None

                ack, nack = self._search_ack(fid=self.MSG_ID_READ_MEMORY)
                if not ack:
                    self._node_print('No Ack received.')
                    return None
            else:
                self._node_print('No Ack received.')
                return None

        else:
            self._node_print('Transport not specified.')
            return False

        return reply

    def _write_block(self, byteaddr, data):
        """Writeup to 255 bytes."""
        # Send write address
        a0 = (byteaddr & 0xFF000000) >> 24
        a1 = (byteaddr & 0x00FF0000) >> 16
        a2 = (byteaddr & 0x0000FF00) >> 8
        a3 = (byteaddr & 0x000000FF)

        # Send size in bytes
        s = len(data)

        if s & 0x3:
            print('Write size must be multiple of 4')
            return False

        # Send size in bytes
        if byteaddr & 0x3:
            print('Write address must be 4 byte aligned')
            return False

        if self.transport == 'uart':
            # Get information from the ROM Bootloader
            writecmd = bytearray([self.MSG_ID_WRITE_MEMORY, 0xCE])
            self._send_uart(writecmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Write command returned unexpected reply')
                return False
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Write command returned unexpected reply')
                    return False

            crc = (a0 ^ a1 ^ a2 ^ a3) & 0xFF

            writecmd = bytearray([a0, a1, a2, a3, crc])
            self._send_uart(writecmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Write command returned unexpected reply')
                return False
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Write command returned unexpected reply')
                    return False

            # Must supply one less
            s = s - 1

            # CRC
            crc = s
            for i in range(len(data)):
                crc = crc ^ data[i]

            writecmd = bytearray([s]) + data + bytearray([crc])
            self._send_uart(writecmd)

            # See if we got a reply from the ROM bootloader
            reply = self._receive_uart(size=1)
            if len(reply) == 0:
                print('Write command returned unexpected reply')
                return False
            else:
                if reply[0] != self.MSG_ID_ACK:
                    print('Write command returned unexpected reply')
                    return False

        elif self.transport == 'can':
            write_cmd_data = bytearray([a0, a1, a2, a3, s - 1])
            self._send_can(data=write_cmd_data, fid=self.MSG_ID_WRITE_MEMORY)

            ack, nack = self._search_ack(fid=self.MSG_ID_WRITE_MEMORY)
            if ack and not nack:
                for i in range(0, s, 8):
                    self._send_can(data=data[i:i + 8], fid=0x04)

                    ack, nack = self._search_ack(fid=self.MSG_ID_WRITE_MEMORY)
                    if not ack:
                        self._node_print('Failed to write memory')
                        self._node_print('!!STM will need to be power cycled!!')
                        return False

                # Receive final Ack
                ack, nack = self._search_ack(fid=self.MSG_ID_WRITE_MEMORY)
                if not ack:
                    self._node_print('Failed to write memory')
                    return False
            else:
                self._node_print('No Ack received.')
                return False

        else:
            self._node_print('Transport not specified.')
            return False

        return True

    def _flash_size(self):
        """Flash Size."""
        data = self.adv_read(0x1FFF75E0)
        if data is not None:
            fsize = int.from_bytes(data, byteorder='little')
            self.gfsize = (fsize & 0xFFFF) * 1024
            return True
        else:
            self.gfsize = 0
            self._node_print('Failed to read flash size')
            return False

    def _read_options(self):
        """Read user option bits."""
        bytesize = 4

        if self.gchipfamily == 'L4+':
            byteaddr = 0x1FF00000
        else:
            byteaddr = 0x1FFF7800

        data = self._read_block(byteaddr, bytesize)

        if data is not None:
            self.gusropts = data
            self._node_print('User opts: 0x' + '{:08X}'.format(int.from_bytes(data, byteorder='little')))

            # Read protection
            rdp = data[0]
            if rdp == 0xAA:
                self.grdp = 0
            elif rdp == 0xCC:
                self.grdp = 2
            else:
                self.grdp = 1

            flash = ((data[2] & 0xF0) >> 4)

            if self.gchipfamily == 'L4+':
                if ((flash & 0x2) >> 1) == 0x1 or ((flash & 0x4) >> 2) == 0x1:
                    self.gdbank = True
                else:
                    self.gdbank = False

                if (flash & 0x1) == 0x1:
                    self.gdbankboot = True
                else:
                    self.gdbankboot = False
            else:
                self.gdbank = False
        else:
            print('Read Opts error: ' + hex(byteaddr) + ' Size = 4b')
            return False

        return True

    def _read_wrp(self):
        """Read write protection registers."""
        bytesize = 4

        if self.gchipfamily == 'L4+':
            byteaddr_bank1a = 0x1FF00018
            byteaddr_bank1b = 0x1FF00020
            byteaddr_bank2a = 0x1FF01018
            byteaddr_bank2b = 0x1FF01020

            # Bank 1 Area A
            data = self._read_block(byteaddr_bank1a, bytesize)

            if data is not None:
                self.gwrpbank1a = data
            else:
                print('Read WRP bank 1 area A error: ' + hex(byteaddr_bank1a) + ' Size = 8b')
                return False

            # Bank 1 Area B
            data = self._read_block(byteaddr_bank1b, bytesize)

            if data is not None:
                self.gwrpbank1b = data
            else:
                print('Read WRP bank 1 area B error: ' + hex(byteaddr_bank1b) + ' Size = 8b')
                return False

            # Bank 2 Area A
            data = self._read_block(byteaddr_bank2a, bytesize)

            if data is not None:
                self.gwrpbank2a = data
            else:
                print('Read WRP bank 2 area A error: ' + hex(byteaddr_bank2a) + ' Size = 8b')
                return False

            # Bank 2 Area B
            data = self._read_block(byteaddr_bank2b, bytesize)

            if data is not None:
                self.gwrpbank2b = data
            else:
                print('Read WRP bank 2 area B error: ' + hex(byteaddr_bank2b) + ' Size = 8b')
                return False

            return True
        else:
            byteaddr_bank1a = 0x1FFF7818
            byteaddr_bank1b = 0x1FFF7820

            # Bank 1 Area A
            data = self._read_block(byteaddr_bank1a, bytesize)

            if data is not None:
                self.gwrpbank1a = data
            else:
                print('Read WRP bank 1 area A error: ' + hex(byteaddr_bank1a) + ' Size = 8b')
                return False

            # Bank 1 Area B
            data = self._read_block(byteaddr_bank1b, bytesize)

            if data is not None:
                self.gwrpbank1b = data
            else:
                print('Read WRP bank 1 area B error: ' + hex(byteaddr_bank1b) + ' Size = 8b')
                return False

            return True

    def _get_nodedef(self):
        """Read nodedef from file."""
        directory = os.path.dirname(os.path.realpath(__file__))
        nodes_file_name = os.path.join(directory, 'nodes.json')

        if not os.path.exists(nodes_file_name):
            print('Error: Could not open nodedef.json')
            raise NodedefIOFailure

        with builtins.open(nodes_file_name, mode='r') as nodes_cfg:
            nodes = json.loads(nodes_cfg.read())

        return nodes

    def _identify_node(self, data):
        """Identify node from raw OTP dump."""
        [node_id, revision] = struct.unpack_from('<II', data[0:8], )

        nodedef = self._get_nodedef()

        node_identifier = [node for node in nodedef.keys() if nodedef[node] == node_id]

        try:
            node = node_identifier[0]
        except Exception:
            node = []
            revision = []

        return node, revision

    def check_driver(self, driver_string):
        """Check if driver exists."""
        ret = 1
        if 'win32' in sys.platform:
            ret = os.system(f'driverquery | findstr {driver_string} > nul 2>&1')
        elif 'linux' in sys.platform:
            if driver_string == 'PCAN_USB':
                ret = os.system('modinfo pcan > /dev/null 2>&1')
            else:
                self._node_print(f'{driver_string} Device not supported on {sys.platform}')
        else:
            ret = 0
            self._node_print(f'Platform {sys.platform} not supported.')

        return ret == 0

    def check_can_interface(self, interface):
        """Check that the provided CAN interface is present."""
        ret = 1
        if 'linux' in sys.platform:
            ret = os.system(f'ip addr | grep {interface} > /dev/null 2>&1')
        else:
            self._node_print(f'Interface {interface} not supported on Platform {sys.platform}.')

        return ret == 0

    def set_transport(self, transport='uart', com_port=None, can_interface='can0', can_baud=None):
        """Set the transport for this operation."""
        self._node_print(f'Set Transport: {transport} Baud: {self.CAN_BAUD_TRANSLATION[can_baud]} Port: {com_port}')

        self.transport = transport
        self.com_port = com_port
        self.can_interface = can_interface
        self.can_baud_pcan = can_baud

    def get_transport(self):
        """Get the configured transport."""
        return self.transport

    def list_interfaces(self):
        """Enumerate the supported interfaces."""
        print('\r\n************ UART ************')
        ports = serial.tools.list_ports.comports(include_links=True)
        numports = len(ports)
        print('Interfaces detected : ' + str(numports))
        for p in ports:
            print('Name:   ' + p.device)
            print('Serial: ' + p.hwid)

        print('\r\n************ CAN *************')
        if 'win32' in sys.platform:
            ret = os.system('wmic path CIM_LogicalDevice where "Description like \'PCAN-USB\'" get /value | findstr PCAN-USB > nul 2>&1')
            if ret == 0:
                print('PCAN-USB')
        elif 'linux' in sys.platform:
            os.system('ip addr | grep can')
        else:
            print(f'{sys.platform} is not supported.')

        print('')

    def set_verbose(self):
        """Verbose Setting."""
        self.verbose = True

    def clear_dual_bank_boot(self):
        """Clear the BFB2 user options flag."""
        if self.gchipfamily == 'L4+' and self.gdbankboot:
            opened = self._open()

            if opened is False:
                raise PortFailure

            self._node_print('Clearing dual bank boot...')

            usropts = int.from_bytes(self.gusropts, byteorder='little')
            usropts &= ~self.FLASH_OPTR__MASK_BFB2
            self.gusropts = usropts.to_bytes(4, 'little')
            byteaddr = 0x1FF00000
            self._write_block(byteaddr, self.gusropts)

            self._node_print('Cleared.')

    def write_can_speed(self, speed):
        """
        Write the CAN baud rate to the STM bootloader.

        The STM bootloader boots with a default 125kbps baud rate.
        This must be changed every time the device is power cycled.
        """
        if speed is not None and speed != '1':
            self._node_print(f'Changing CAN runtime baud rate to {self.CAN_BAUD_TRANSLATION[speed]}')

            try:
                # Open interface
                opened = self._open()

                if opened is False:
                    raise PortFailure

                self._send_can(data=[int(speed)], fid=self.MSG_ID_SPEED)

                ack, nack = self._search_ack(fid=self.MSG_ID_SPEED)
                if not ack:
                    self._node_print('No Ack on Speed command')
                    raise CommsFailure

                self._close()

                # Test the new baud rate
                self.set_transport(transport='can', can_interface=self.can_interface, can_baud=speed)

                time.sleep(0.5)

                opened = self._open()

                if opened is False:
                    raise PortFailure

                ack, nack = self._search_ack(fid=self.MSG_ID_SPEED)
                if ack and not nack:
                    return True
                else:
                    self._node_print('No 2nd Ack on Speed command')
                    raise CommsFailure

            except (CommsFailure, PortFailure):
                return False

    def translate_address(self, address):
        """
        Translate an address if dual bank boot (BFB2) is enabled.

        This is required because if BFB2 is set the memory aliasing will be inverted
        when the applications run, but the aliasing is NOT yet inverted when running the ROM bootloader.
        i.e. When using cube-toolbox, we know that all operations will be performed on the specified address,
        so we need to translate these addresses when writing applications and configs.
        """
        if self.gdbankboot:
            # BFB2 is set, we need to translate the address according to bank size
            bank_size = int(self.gfsize / 2)
            if (address - self.gflashorigin) < bank_size:
                newaddress = address + bank_size  # Move address to bank 2
            else:
                newaddress = address - bank_size  # Move address to bank 1

            print(f'Dual Bank Boot...Address translated from {hex(address)} to {hex(newaddress)}')
            return newaddress
        else:
            # Just return the original address
            return address

    def getstate(self):
        """Get information."""
        try:
            # Open interface
            opened = self._open()

            if opened is False:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if not self._info():
                raise CommsFailure

            if not self._options():
                raise CommsFailure

            if not self._chip():
                raise CommsFailure

            if not self._read_options():
                raise CommsFailure

            if not self._read_wrp():
                raise CommsFailure

            self._close()

            if not self._flash_size():
                raise CommsFailure

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def flash_page_size(self):
        """Return page size."""
        if self.gdbank:
            # CAN bootloader protocol doesn't support extended erase, page size is always 8K
            if self.transport == 'can':
                return 8192
            else:
                return self.gdfpage
        else:
            return self.gfpage

    def flash_dual_bank(self):
        """Dual bank."""
        return self.gdbank

    def flash_set_dual_bank(self, dbank):
        """Set the DBANK option bit."""
        if self.gchipfamily != 'L4+':
            print('Chip family must be L4+')
            return False

        opened = self._open()

        if opened is False:
            raise PortFailure

        usropts = int.from_bytes(self.gusropts, byteorder='little')
        if dbank == 0:
            usropts &= ~self.FLASH_OPTR__MASK_DBANK
        else:
            usropts |= self.FLASH_OPTR__MASK_DBANK
        self.gusropts = usropts.to_bytes(4, 'little')
        byteaddr = 0x1FF00000
        return self._write_block(byteaddr, self.gusropts)

    def flash_dual_bank_boot(self):
        """Dual bank boot."""
        return self.gdbankboot

    def print_state(self):
        """Get information."""
        # General
        print('')
        print(':: INFO ::')
        print('')
        print('Rom Protocol Version: ' + self.gversion)
        print('Caps: ' + ' '.join(['{:02x}'.format(x) for x in self.gcaps]))
        print('Opts: ' + ' '.join(['{:02x}'.format(x) for x in self.goptions]))
        print('Chip ID: ' + self.gchip)
        print('Chip Name: ' + self.gchipname)
        print('Read Protection Level: ' + str(self.grdp))
        print('Flash Dual Bank Mode: ' + str(self.gdbank))
        print('Flash Size: ' + self._convert_size(self.gfsize))
        if self.gdbank:
            print('Dual Flash Bank 1: ' + str(int(self.gfsize / self.gdfpage / 2))
                  + ' (0-' + str(int(self.gfsize / self.gdfpage / 2) - 1) + ') Pages, '
                  + self._convert_size(self.gdfpage) + ' per page')
            print('Dual Flash Bank 2: ' + str(int(self.gfsize / self.gdfpage / 2))
                  + ' (' + str(int(self.gfsize / self.gdfpage / 2)) + '-' + str(int(self.gfsize / self.gdfpage) - 1)
                  + ') Pages, ' + self._convert_size(self.gdfpage) + ' per page')
            print('*** NOTE ***')
            print('If using the CAN transport the page size used during operations is always 8K.')
            print('The ST Bootloader does not support extended erase on the CAN interface.')
        else:
            print('Single Bank: ' + str(self.gfsize / self.gfpage)
                  + ' (0-' + str(int(self.gfsize / self.gfpage) - 1) + ') Pages, '
                  + self._convert_size(self.gfpage) + 'per page')

        print('')
        print(':: OPTIONS ::')
        print('')
        # Brown Out Level
        bo = self.gusropts[1] & 0x7
        print('Brown Out Level (BOR_LEV): ' + str(bo))
        # Reset settings
        rst = (self.gusropts[1] & 0x70) >> 4
        print('No reset when STOP (nRST_STOP): ' + str(rst & 0x1))
        print('No reset when STANDBY (nRST_STDBY): ' + str((rst & 0x2) >> 1))
        print('No reset when SHUTDOWN (nRST_SHDW): ' + str((rst & 0x4) >> 2))
        # Watchdogs
        wdg = (self.gusropts[2] & 0xF)
        print('Independant watchdog AUTO start (IWDG_SW): ' + str(~wdg & 0x1))
        print('Independant watchdog freeze when STOP (IWDG_STOP): ' + str((~wdg & 0x2) >> 1))
        print('Independant watchdog fereze when STANDBY (IWDG_STDBY): ' + str((~wdg & 0x4) >> 2))
        print('Embedded watchdog AUTO start (WWDG_SW): ' + str((~wdg & 0x8) >> 3))
        flash = ((self.gusropts[2] & 0xF0) >> 4)

        if self.gchipfamily == 'L4+':
            # Flash dual bank (only supported on STM32L4+)
            print('STM32L4+ Dual bank flash boot ENABLED (BFB2): ' + str(flash & 0x1))
            print('STM32L4+ Dual bank ENABLED for 512KB/1MB devices (DB1M): ' + str((flash & 0x2) >> 1))
            print('STM32L4+ Dual bank ENABLED for 2MB devices (DBANK): ' + str((flash & 0x4) >> 2))

        # Bootloader options
        print('ROM bootloader option bit 1 (nBOOT1): ' + str((flash & 0x8) >> 3))
        bldr = self.gusropts[3] & 0xF
        print('SRAM2 Parity Check ENABLED (SRAM2_PE): ' + str(~bldr & 0x1))
        print('SRAM2 Erase on reset (SRAM2_RST): ' + str((~bldr & 0x2) >> 1))
        print('BOOT0 taken from PH3/BOOT0 pin (nSWBOOT0): ' + str((bldr & 0x4) >> 2))
        print('ROM Bootloader option bit 0 (nBOOT0): ' + str((bldr & 0x8) >> 3))

        print('')
        print(':: WRITE PROTECTION ::')
        print('')
        if self.gwrpbank1a is not None:
            print(f'Write Protection [value] WRP1A_STRT: {hex(self.gwrpbank1a[0])}')
            print(f'Write Protection [value] WRP1A_END: {hex(self.gwrpbank1a[2])}')
            if self.verbose:
                print(f'Write Protection [bytes] Bank 1 Area A: {self.gwrpbank1a}')
        if self.gwrpbank1b is not None:
            print(f'Write Protection [value] WRP1B_STRT: {hex(self.gwrpbank1b[0])}')
            print(f'Write Protection [value] WRP1B_END: {hex(self.gwrpbank1b[2])}')
            if self.verbose:
                print(f'Write Protection [bytes] Bank 1 Area B: {self.gwrpbank1b}')
        if self.gwrpbank2a is not None:
            print(f'Write Protection [value] WRP2A_STRT: {hex(self.gwrpbank2a[0])}')
            print(f'Write Protection [value] WRP2A_END: {hex(self.gwrpbank2a[2])}')
            if self.verbose:
                print(f'Write Protection [bytes] Bank 2 Area A: {self.gwrpbank2a}')
        if self.gwrpbank2b is not None:
            print(f'Write Protection [value] WRP2B_STRT: {hex(self.gwrpbank2b[0])}')
            print(f'Write Protection [value] WRP2B_END: {hex(self.gwrpbank2b[2])}')
            if self.verbose:
                print(f'Write Protection [bytes] Bank 2 Area B: {self.gwrpbank2b}')

    def execute(self, address):
        """Execute an image."""
        try:

            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            self._jump(address)

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def read(self, byteaddr, bytesize):
        """Return byte array."""
        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            total = bytearray([])
            bytes_left = bytesize
            for c in range(int((bytesize + 255) / 256)):
                if bytes_left < 256:
                    data = self._read_block(byteaddr + (c * 256), bytes_left)
                else:
                    data = self._read_block(byteaddr + (c * 256), 256)
                    bytes_left -= 256

                if data is not None:
                    total += data
                else:
                    print('Read error: Offset=' + hex(byteaddr + (c * 256)) + ' Size <= 256b')
                    break

            self._close()

            return total

        except (CommsFailure, PortFailure):
            self._close()

    def write(self, byteaddr, data, repeat):
        """Write byte array."""
        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if repeat > 0:
                rdata = bytearray([])
                for i in range(repeat):
                    rdata += data
                data = rdata

            bytesize = len(data)
            bytesleft = bytesize
            for c in range(int((bytesize + 255) / 256)):
                if bytesleft < 256:
                    pdata = data[(c * 256):(c * 256) + bytesleft]
                    result = self._write_block(byteaddr + (c * 256), pdata)
                else:
                    pdata = data[(c * 256):(c * 256) + 256]
                    result = self._write_block(byteaddr + (c * 256), pdata)
                    bytesleft -= 256
                if not result:
                    print('Write error: Offset=' + hex(byteaddr + (c * 256)) + ' Size <= 256b')
                    return False

                progress = int(100 * ((bytesize - bytesleft) / bytesize))
                if (progress % 5) == 0:
                    print(f'{progress}%', end='\r')

            self._close()

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def adv_read(self, address):
        """Hook Read."""
        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            bytesize = 4
            byteaddr = address

            # Patch read address
            self.ghookread[36:40] = bytearray(address.to_bytes(4, 'little'))

            data = None
            if self._write_block(self.ghookaddress, self.ghookread):
                self._jump(self.ghookaddress)

                # Wait for ROM reboot
                time.sleep(0.1)

                if not self._wake():
                    raise CommsFailure

                bytesize = 4
                byteaddr = self.ghookresult

                data = self._read_block(byteaddr, bytesize)

            self._close()

            return data

        except (CommsFailure, PortFailure):
            self._close()
            return None

    def read_unprotect(self):
        """Disable all read-protection."""
        print('Removing read protection...')
        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if self.transport == 'uart':
                unprotectcmd = bytearray([self.MSG_ID_READOUT_UNPROTECT, 0x6D])
                self._send_uart(unprotectcmd)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Read unprotect command returned unexpected reply')
                    print('no first reply')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Read unprotect command returned unexpected reply')
                        print('no first ack')
                        raise CommsFailure
                time.sleep(2)
                # eceive 2nd ack
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Read unprotect command returned unexpected reply')
                    print('no second reply')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Read unprotect command returned unexpected reply')
                        print('no second ack')
                        raise CommsFailure

            elif self.transport == 'can':
                self._send_can(data=[0x00], fid=self.MSG_ID_READOUT_UNPROTECT)

                ack, nack = self._search_ack(fid=self.MSG_ID_READOUT_UNPROTECT)
                if ack and not nack:
                    time.sleep(0.5)
                    ack, nack = self._search_ack(fid=self.MSG_ID_READOUT_UNPROTECT, timeout=1)
                    if not ack or nack:
                        self._node_print('Read Unprotect command failed.')
                        raise CommsFailure
                else:
                    self._node_print('ReadOut Protection is active.')
                    raise CommsFailure
            else:
                self._node_print('Transport not specified.')
                raise PortFailure

            self._close()

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def write_unprotect(self):
        """Disable all write-protection."""
        print('Removing write protection...')
        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if self.transport == 'uart':
                unprotectcmd = bytearray([self.MSG_ID_WRITE_UNPROTECT, 0x8C])
                self._send_uart(unprotectcmd)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Write unprotect command returned unexpected reply')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Write unprotect command returned unexpected reply')
                        raise CommsFailure

                # eceive 2nd ack
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Write unprotect command returned unexpected reply')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Write unprotect command returned unexpected reply')
                        raise CommsFailure

            elif self.transport == 'can':
                self._send_can(data=[0x00], fid=self.MSG_ID_WRITE_UNPROTECT)

                ack, nack = self._search_ack(fid=self.MSG_ID_WRITE_UNPROTECT)
                if ack and not nack:
                    time.sleep(0.5)
                    ack, nack = self._search_ack(fid=self.MSG_ID_WRITE_UNPROTECT, timeout=1)
                    if not ack or nack:
                        self._node_print('Write Unprotect command failed.')
                        raise CommsFailure
                else:
                    self._node_print('ReadOut Protection is active.')
                    raise CommsFailure
            else:
                self._node_print('Transport not specified.')
                raise PortFailure

            self._close()

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def write_identity(self, identity):
        """Write identity to node OTP section."""
        identity_array = identity.split('-')

        revision = identity_array[-1]
        node = '-'.join(identity_array[0:-1])

        nodedef = self._get_nodedef()

        try:
            if not revision.isnumeric():  # Force invalid revision exception
                raise InputIdentityFailure

            node_id = nodedef[node]
            node_rev = int(revision)

        except Exception:
            print('Error: Invalid identifier specified (format E.g cube-computer-5)')
            raise InputIdentityFailure  # Catch and raise away

        byte_string = struct.pack('<II', node_id, node_rev)

        self.write((self.gotpaddress + self.OTP_OFFSET_NODE_ID_NUMBER), byte_string, 0)

        print(f'Wrote {identity} id to node')

    def write_serial(self, serial):
        """Write production serial to node OTP section."""
        try:
            if len(serial) >= 16:
                raise InputValue

        except Exception:
            print('Error: Production Serial must be 15 chars max (format E.g "CS21001")')
            raise InputValue

        byte_string = struct.pack('<32s', serial.encode('utf-8'))

        print(f'Target OTP address: 0x{self.gotpaddress + self.OTP_OFFSET_NODE_PRODUCTION_SERIAL:02x}')

        self.write((self.gotpaddress + self.OTP_OFFSET_NODE_PRODUCTION_SERIAL), byte_string, 0)

        print(f'Wrote serial: {serial} to node')

    def read_identity(self):
        """Read Identity from OTP dump."""
        raw_data = self.read((self.gotpaddress + self.OTP_OFFSET_NODE_ID_NUMBER), 8)
        data = list(set(raw_data))

        if len(data) > 1:
            node, revision = self._identify_node(raw_data)
        elif (len(data) == 1) and (data[0] == 0xFF):
            node = 0xFF
            revision = []
        else:
            print('Error: No bytes read from target')
        return node, revision

    def read_serial(self):
        """Read Identity from OTP dump."""
        raw_data = self.read((self.gotpaddress + self.OTP_OFFSET_NODE_PRODUCTION_SERIAL), 32)
        serial = ''.join(map(chr, raw_data))
        serial.rstrip('\x00')
        return serial

    def erase_all(self, bank):
        """Erase all internal flash."""
        if bank >= 3:
            print('Error: Bank should be 0-2')
            return False

        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if self.transport == 'uart':
                # Get information from the ROM Bootloader
                erasecmd = bytearray([self.MSG_ID_ERASE_EXTENDED, 0xBB])
                self._send_uart(erasecmd)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Erase command returned unexpected reply')
                    print('no reply 1')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Erase command returned unexpected reply')
                        print('nack reply 1')
                        raise CommsFailure

                # Send erase code 16-bit
                pattern = 0xFFFF - bank
                a0 = (pattern & 0x0000FF00) >> 8
                a1 = (pattern & 0x000000FF)
                crc = (a0 ^ a1) & 0xFF

                erasecmd = bytearray([a0, a1, crc])
                self._send_uart(erasecmd)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Erase command returned unexpected reply')
                    print('n0 reply 2')
                    raise CommsFailure
                else:
                    if reply[0] != self.MSG_ID_ACK:
                        print('Erase command returned unexpected reply')
                        print('nack reply 2')
                        raise CommsFailure

            elif self.transport == 'can':
                self._send_can(data=[0xFF], fid=self.MSG_ID_ERASE)

                ack, nack = self._search_ack(fid=self.MSG_ID_ERASE)
                if not ack:
                    self._node_print('Erase all failed first Ack')
                    return False

                ack, nack = self._search_ack(fid=self.MSG_ID_ERASE)
                if not ack:
                    self._node_print('Erase all failed second Ack')
                    return False
            else:
                self._node_print('Transport not specified.')
                return False

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def erase(self, page, count):
        """Erase flash blocks."""
        if count < 1:
            print('Error: Invalid page count')
            return False

        try:
            # Open interface
            opened = self._open()
            if not opened:
                raise PortFailure

            if not self._wake():
                raise CommsFailure

            if self.transport == 'uart':
                # Get information from the ROM Bootloader
                erasecmd = bytearray([self.MSG_ID_ERASE_EXTENDED, 0xBB])
                self._send_uart(erasecmd)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)
                if len(reply) == 0:
                    print('Erase command returned unexpected reply')
                    print('no reply 1')
                    raise CommsFailure
                else:
                    print(reply)
                    if reply[0] != self.MSG_ID_ACK:
                        print('Erase command returned unexpected reply')
                        print('no ack 1')
                        raise CommsFailure

                # Number of Pages
                number = count - 1
                a0 = (number & 0x0000FF00) >> 8
                a1 = (number & 0x000000FF)

                erasecmd = bytearray([a0, a1])
                crc = (a0 ^ a1) & 0xFF

                # Pages
                for p in range(count):
                    pages = page + p
                    a2 = (pages & 0x0000FF00) >> 8
                    a3 = (pages & 0x000000FF)
                    crc = (crc ^ a2 ^ a3) & 0xFF
                    erasecmd += bytearray([a2, a3])

                erasecmd += bytearray([crc])
                self._send_uart(erasecmd)

                time.sleep(5)

                # See if we got a reply from the ROM bootloader
                reply = self._receive_uart(size=1)

                if len(reply) == 0:
                    print('Erase command returned unexpected reply')
                    print('no reply 2')
                    raise CommsFailure
                else:
                    print(reply)
                    if reply[0] != self.MSG_ID_ACK:
                        print('Erase command returned unexpected reply')
                        print('no ack 2')
                        raise CommsFailure

            elif self.transport == 'can':
                # Extended erase is not available on CAN interface
                # Number of Pages
                pages = list()
                for p in range(count):
                    pages.append(page + p)

                self._send_can(data=[count - 1], fid=self.MSG_ID_ERASE)
                time.sleep(0.8)  # fix a timeout bug on some computers

                for i in range(0, count, 8):
                    self._send_can(data=pages[i:i + 8], fid=self.MSG_ID_ERASE)

                ack, nack = self._search_ack(num_ack=2, num_nack=1, fid=self.MSG_ID_ERASE)
                if not ack or nack:
                    self._node_print('Erase command no Ack.')
                    raise CommsFailure
            else:
                self._node_print('Transport not specified.')
                raise PortFailure

            self._close()

            return True

        except (CommsFailure, PortFailure):
            self._close()
            return False

    def close(self):
        """Close active interface."""
        self._close()
