"""
Main CLI entry to cube-toolbox.

cubetoolbox.main is accessible within python scripts.
"""
import sys
import cubetoolbox


"""
########################################################################################
## NODEDEF COMMS
########################################################################################
"""
"""
#    if args.ndpath is not None:
#        nodedefs.location(args.ndpath)

#    if args.ndlist == True:
#        print()
#        print('Nodedefs supported:')
#        for n in nodedefs.nodes():
#            print('\nNode: ' + n)
#            for a in nodedefs.apps(n):
#                print('\tApp: " + a)
"""
if __name__ == '__main__':
    ret = cubetoolbox.main(sys.argv[1:])

    if ret is True:
        sys.exit(0)
    else:
        sys.exit(1)
